# Guía para la Entrega de Bienes Culturales Muebles

> **Tipo:** Resolución Viceministerial
> **Número:** RV N° 00171-2020-VMPCIC
> **Fecha de publicación:** 2020
> **Estado:** Vigente

---

GUÍA N° 001-2020-VMPCIC/MC

CRITERIOS BÁSICOS PARA LA ENTREGA DE BIENES CULTURALES MUEBLES PROCEDENTES DE PROYECTOS DE INTERVENCIÓN ARQUEOLÓGICA AL MINISTERIO DE CULTURA

1. OBJETIVO

La presente Guía es un instrumento técnico que permite orientar y uniformizar los criterios y procedimientos empleados durante las actividades de almacenaje temporal, inventario, embalaje y desplazamiento de los bienes culturales muebles recuperados en el marco de proyectos de intervención arqueológica, hasta su entrega y recepción formal por parte del Ministerio de Cultura.

2. BASE LEGAL

 Ley N° 28296, Ley General del Patrimonio Cultural de la Nación y sus modificatorias.

 Ley N° 29565, Ley de creación del Ministerio de Cultura y su modificatoria.

 Decreto Supremo N° 005-2013-MC, que aprueba el Reglamento de Organización y Funciones del Ministerio de Cultura.

 Decreto Supremo N° 003-2014-MC, que aprueba el Reglamento de Intervenciones Arqueológicas y su modificatoria.

 Decreto Supremo N° 011-2006-ED, que aprueba el Reglamento de la Ley N° 28296, Ley General del Patrimonio Cultural de la Nación y modificatorias.

 Decreto Supremo Nº 004-2019-JUS, que aprueba el Texto Único Ordenado de la Ley Nº 27444 - Ley del Procedimiento Administrativo General.

 Resolución Directoral N° 000040-2016/DGM/VMPCIC/MC, que aprueba el Manual de Procedimientos en el Sistema Informatizado de Registro de Bienes Muebles Integrantes del Patrimonio Cultural de la Nación.

3. ALCANCE

Las disposiciones contenidas en la presente Guía son de aplicación obligatoria para la Dirección General de Museos, la Dirección General de Patrimonio Arqueológico Inmueble, las Direcciones Desconcentradas de Cultura, así como para personas naturales y jurídicas que desarrollen proyectos de intervención arqueológica autorizados por el Ministerio de Cultura.

4. RESPONSABILIDAD

4.1. La Dirección General de Museos, la Dirección General de Patrimonio Arqueológico Inmueble y las Direcciones Desconcentradas de Cultura, en el marco de sus competencias, son responsables de velar por el cumplimiento de las disposiciones contenidas en la presente Guía. 4.2. Las personas naturales o jurídicas autorizadas por el Ministerio de Cultura para ejecutar proyectos de intervención arqueológica son responsables de cumplir los criterios técnicos dispuestos en la presente Guía durante las actividades de almacenaje temporal, inventario, embalaje y desplazamiento

de los bienes culturales muebles, hasta su entrega final al Ministerio de Cultura.

4.3. Las Direcciones Desconcentradas de Cultura, los museos u otras instituciones designadas por el Ministerio de Cultura para almacenar los bienes culturales muebles procedentes de proyectos de intervención arqueológica, son responsables de supervisar y verificar su adecuada entrega y recepción.

5. DISPOSICIÓN GENERAL

La presente Guía contiene criterios y procedimientos básicos que deben considerarse durante la ejecución de proyectos de intervención arqueológica, en las actividades de almacenaje temporal, embalaje, desplazamiento, entrega y recepción de los bienes culturales muebles recuperados a fin de garantizar su conservación, preservación y seguridad.

6. DISPOSICIONES ESPECÍFICAS

6.1. DEL ALMACENAJE TEMPORAL EN GABINETES, LABORATORIOS O DEPÓSITOS DE LOS PROYECTOS DE INTERVENCIÓN ARQUEOLÓGICA

6.1.1. El ambiente destinado para el almacenaje temporal o análisis de los bienes culturales muebles debe reunir las condiciones mínimas de conservación y seguridad: de uso exclusivo, amplio, libre de plagas, seco, ventilado, limpio, seguro, techado y con instalaciones eléctricas y de agua en buenas condiciones. 6.1.2. Evitar almacenar productos potencialmente peligrosos, tales como: insumos químicos, materiales inflamables o contaminantes; asimismo, se debe evitar guardar, preparar o consumir alimentos dentro de los ambientes y restringir el ingreso de animales. 6.1.3. No colocar los bienes culturales muebles, empaques o cajas que los contengan en contacto directo con el piso, o de forma apilada.

6.1.4. Las mesas de trabajo y el mobiliario donde se almacenan los bienes culturales (tarimas, estantes, armarios, entre otros) deben ser estables, fijos y resistentes a las plagas; y en caso se encuentre en contacto directo con los bienes culturales muebles debe ser forrado con materiales inertes.

6.2. DE LAS ACCIONES DE CONSERVACIÓN

6.2.1. Durante el desarrollo de las actividades de manipulación, almacenaje temporal, embalaje y desplazamiento se deben tomar medidas de conservación preventiva, orientadas a evitar o disminuir los riesgos externos que pudiesen producir daño o deterioro de los bienes culturales muebles.  6.2.2. La intervención de los bienes culturales muebles solo se efectúa cuando se encuentren en proceso o potencial deterioro y con la finalidad de lograr su estabilidad e integridad. Debe ser realizada por personal con formación y/o experiencia en conservación de bienes culturales muebles arqueológicos, empleando procedimientos, productos o insumos reversibles, compatibles y que no sufran alteraciones a través del tiempo; de acuerdo con lo establecido en el artículo 46 del Reglamento de la Ley General de Patrimonio Cultural de la Nación.

6.2.3. La intervención de los bienes culturales muebles debe ser documentada en un informe técnico, que contenga fotografías de todo el proceso y fichas que detallen el análisis, diagnóstico, tratamiento, insumos, procedimientos, resultados y responsable de la intervención.

6.3. DE LOS CRITERIOS DE AGRUPACIÓN DE LOS BIENES CULTURALES MUEBLES

La agrupación y clasificación de los bienes culturales muebles, para efectos de su inventario y embalaje, se efectúa de acuerdo con los siguientes criterios:

6.3.1. Tomar en cuenta el contexto y asociación, tanto espacial (sitio, sector, unidad de excavación, etc.) como estratigráfico (capa y/o nivel). 6.3.2. Clasificar los bienes culturales muebles de acuerdo a su naturaleza: orgánica (botánico, malacológico, resto humano, resto animal, textil o papel) o inorgánica (lítico, cerámica, metal, mineral o paleontológico), además de las muestras para su posterior análisis especializado. 6.3.3. Separar los objetos de acuerdo a su peso, dimensión y estado de integridad (completo, incompleto y/o fragmentado). Los fragmentos de cerámica se pueden subdividir en diagnóstico/no diagnóstico.

6.3.4. Aislar los objetos frágiles o que se encuentren en mal estado de conservación para evitar que puedan sufrir daños o que se acelere el proceso de deterioro.

6.3.5. Se debe evitar separar los conjuntos de materiales de distinta naturaleza que se hallen unidos físicamente, como fardos funerarios, costureros, entre otros.

6.3.6. En el caso de los análisis de flotación, se entregan solo las muestras resultantes.

6.4. DE LA IDENTIFICACIÓN DE LOS BIENES CULTURALES MUEBLES

6.4.1. Rótulos 6.4.2. Etiquetas individuales  6.4.3. Etiquetas para cajas

6.5. DEL INVENTARIO Y REGISTRO FOTOGRÁFICO

6.5.2. Registro fotográfico de los bienes museables

6.6. DEL EMBALAJE DE LOS BIENES CULTURALES MUEBLES

Se pueden colocar rótulos en los artefactos con superficies duras como vidrio, cerámica, metal, madera, hueso, piedra y concha,

empleando una base de resina acrílica aplicada antes y después del rotulado.

Los rótulos deben ubicarse en un lugar poco visible o que pase desapercibido, ser legibles, de tamaño proporcional a las dimensiones del objeto y contener códigos de identificación estandarizados.

Se debe evitar colocar rótulos sucesivos sobre los bienes, o inscripciones ilegibles o ambiguas.

No se debe emplear sellos, plumones, tizas, correctores líquidos, o colocar etiquetas adhesivas de cualquier tipo, sujetadores, alfileres o grapas sobre los bienes culturales.

Todos los bienes culturales deben contar con etiquetas, que son elaboradas de preferencia en cartulina o papel blanco, conteniendo como mínimo la información que se detalla en el anexo 1 de la presente Guía, impresa o escrita en idioma español.

Las etiquetas se colocan dentro de una bolsa de polipropileno de al menos dos micras de espesor para evitar su deterioro.

Cada etiqueta se ubica al interior de las cajas o bolsas que contengan los bienes culturales muebles, y de ser posible, atada al objeto con hilo de algodón.

Las etiquetas son de papel blanco, de tamaño A4, A5 o proporcional a las dimensiones de la caja, y contienen como mínimo la información impresa que se detalla en el anexo 1 de la presente Guía, la misma que debe ser consignada en idioma español.

Las etiquetas son colocadas en dos lados verticales contiguos de la caja, adheridas con cola sintética y protegidas con cinta adhesiva o mica transparente para evitar que se puedan desprender.

6.5.1. Inventario general

El inventario general incluye la información de todos los bienes culturales muebles recuperados durante la ejecución de la intervención arqueológica, para lo cual se empleará el formato que contendrá como mínimo la información detallada en el anexo 2 de la presente Guía.

Se efectuará un registro fotográfico de los bienes museables, que corresponden a los artefactos representativos, de interés científico o que presenten más del cincuenta por ciento (50%) de integridad.

Se toma una vista general del bien, sobre fondo neutro, con escala gráfica y código de identificación (ver modelo en el anexo 3 de la presente Guía).

Las imágenes se almacenan en formato .jpg, con un peso promedio de 2 MB, codificadas de acuerdo con el número de inventario.

6.6.1. Contenedores

a. Se pueden utilizar cajas plásticas, de cartón plástico corrugado blanco, de madera o de cartón, las cuales deberán ser resistentes, de primer uso y no tener elementos de metal.

b. Emplear cajas de dimensiones uniformes que tengan un promedio de 50 cm de largo, 30 cm de ancho y 30 cm de alto, o de ser el caso, de las dimensiones establecidas por la institución que recibirá los bienes culturales muebles.

c. El peso promedio del contenido de cada caja no debe sobrepasar los 15 kg, peso que una persona puede manipular manualmente sin sufrir lesiones, de acuerdo con la Norma Básica de Ergonomía y de Procedimiento de Evaluación de Riesgo Disergonómico1.

1 Aprobada con Resolución Ministerial N° 375-2008-TR.

2 Aprobada con Decreto Supremo Nº 011-2006-VIVIENDA.

d. Si los objetos superan los 15 kg se emplean cajones plásticos apilables, cajas de madera o cajas de cartón corrugado de doble onda.

e. Se pueden emplear cajas de madera seca y tratada, como tornillo, catahua amarilla, entre otras, del grupo C de la Norma E.010 del Reglamento Nacional de Edificaciones2. No se recomienda el uso pino o triplay.

f. Si se cuenta con objetos de gran formato, el embalaje deberá confeccionarse de acuerdo a sus dimensiones empleando materiales resistentes.  6.6.2. Empaques y materiales de amortiguamiento

a. Verificar previamente que los bienes culturales muebles se encuentren estables, secos, limpios y libres de plagas.

b. Embalar los bienes culturales por separado, de acuerdo a su naturaleza, forma, peso, dimensiones, estado de conservación y fragilidad.

c. Se emplean bolsas de polietileno o polipropileno transparente de alta densidad, del calibre o grosor mayor a 3 micras. Para el cerramiento se emplea hilo de algodón o nailon, tiras de alambre plastificado o se utilizarán bolsas con cierre hermético.

d. Como materiales aislantes o de amortiguamiento se puede utilizar productos inertes y/o libres de ácido como papel seda blanco, tela notex blanca, espuma de polietileno, napa, papel sin ácido, plástico burbuja, guata, fibras y no tejidos de polipropileno o polietileno, entre otros.

e. Los bienes culturales de pequeño formato como cuentas, micro desechos, entre otros, se guardan dentro de contenedores pequeños con tapa, bolsas con doble cierre hermético o tubos de microcentrífuga de polipropileno, los cuales deberán ser rotulados con tinta indeleble y colocados en bolsas de polietileno o polipropileno.

f. Las muestras para posteriores análisis especializados (radiocarbono, isótopos estables, ADN, difracción de rayos X, entre otros) deberán ser embaladas por separado de acuerdo con los protocolos específicos.

g. No emplear envases de metal, papel periódico, papel higiénico, papel kraft, papel teñido, cintas adhesivas, grapas de metal, telas, ligas de hule/jebe, poliestireno expandido (tecnopor), policloruro de vinilo (PVC), plásticos de un solo uso, esponjas, espumas o plásticos que no sean de polietileno y adhesivos comerciales. 6.7. DEL DESPLAZAMIENTO DE LOS BIENES CULTURALES MUEBLES

6.7.1. Manipular los bienes culturales muebles teniendo en cuenta su fragilidad, estado de conservación y punto de gravedad, empleando guantes de algodón, látex o nitrilo.  6.7.2. Para el desplazamiento de las cajas de manera segura, se recomienda utilizar plataformas móviles, bandejas u otros equipos que faciliten su traslado; bajo ninguna condición se arrastrarán las cajas. 6.7.3. Las cajas no deben permanecer a la intemperie o expuestas a cambios bruscos de temperatura o humedad.

6.7.4. Se recomienda que el vehículo que transporte los bienes culturales muebles cuente con bodega cerrada (tipo furgón). Las cajas deben fijarse al vehículo con fajas o arneses para impedir la vibración y desplazamiento.

6.8. DE LA ENTREGA DE LOS BIENES CULTURALES MUEBLES AL MINISTERIO DE CULTURA 6.8.1. La entrega formal de los bienes culturales muebles se efectúa en el lugar y plazos establecidos en el documento que autorizó la intervención arqueológica.

6.8.2. El director o su representante debidamente acreditado, debe presentar ante la institución designada para la recepción de los bienes culturales muebles:

a. Carta con los datos del proyecto y el número de la Resolución Directoral u otro documento que indique el destino final de los bienes culturales muebles.

b. Inventario general de los bienes culturales impreso.

c. Un USB o CD que contenga la siguiente documentación:

 Inventario general en formato .xls.

 Archivo digital con las fotografías de los bienes museables en formato .jpg, según lo especificado en el inciso 6.5.2 de la presente Guía. Las imágenes deberán estar numeradas de acuerdo con el inventario.

 Etiquetas en formato .doc o .xls.

 De ser el caso, informe y fichas de intervención de los bienes culturales en formato .pdf. 6.8.3. Luego de la revisión de la documentación, se comunica la fecha de entrega de los bienes culturales muebles.

6.9. DE LA RECEPCIÓN DE LOS BIENES CULTURALES MUEBLES

6.9.1. El personal responsable de la recepción de los bienes culturales muebles efectúa su verificación, tomando en cuenta lo siguiente:

- Se adjunte la documentación requerida.

- Los empaques y cajas sean los indicados.

- Los bienes culturales se encuentren estables, secos, limpios y libres de insectos.

- El peso de los bienes culturales sea correcto.

- La verificación de los inventarios.

- Los bienes se encuentren separados de acuerdo a su naturaleza y estado de conservación. 6.9.2. De encontrarse observaciones, el personal encargado las comunica al director del proyecto para que sean subsanadas antes de la suscripción del Acta de entrega y recepción. 6.9.3. Luego de la verificación de los bienes culturales muebles se suscribe el Acta de entrega y recepción de acuerdo con el modelo establecido en el anexo 4 de la presente Guía. Una copia de esta se remite a la Dirección General de Patrimonio Arqueológico Inmueble.

6.9.4. La institución encargada de la recepción de los bienes culturales muebles remite a la Dirección General de Museos la versión digital de los documentos consignados en el inciso 6.8.2 de la presente Guía, incluyendo una copia digital del acta de entrega y recepción.

6.9.5. La Dirección General de Museos elabora una base de datos que contendrá la información de los bienes culturales muebles

procedentes de proyectos de intervención arqueológica, recibidos por el Ministerio de Cultura a nivel nacional.

7. ANEXOS

 Anexo 1 Formatos de etiquetas para cajas y etiquetas individuales, y ejemplos de su llenado.

 Anexo 2 Formato de inventario general de bienes culturales muebles, y ejemplo de su llenado.

 Anexo 3 Ejemplos de vistas para el registro fotográfico de los bienes museables.

 Anexo 4 Modelo de acta de entrega y recepción de bienes culturales muebles, y ejemplo de su llenado.

 Anexo 5 Glosario.

 Anexo 6 Referencias.

ANEXO 1

FORMATO DE ETIQUETA PARA CAJAS

Logo Ministerio.jpg

(

(Nombre y temporada del proyecto)

N° CAJA / TOTAL

Director(es)

Resolución de autorización

Fecha de Resolución

PROCEDENCIA

Región

Provincia

Distrito

Sitio

Sector

Área/Unidad/Pozo

Contexto

IDENTIFICACIÓN

Material

Total de bolsas

Códigos

Peso total (kg)

Observaciones

FORMATO DE ETIQUETA INDIVIDUAL

Logo Ministerio.jpg

(Logotipo del proyecto)

Nombre

N° de caja

N° de bolsa

Código

Denominación

Material

Cantidad

Peso (g)

Descripción

Sitio

Sector

Área/Unidad/Pozo

Capa/UE

Nivel

Cuadrícula

Contexto

Rasgo/elemento

Fecha

Excavado por

Registrado por

EJEMPLO DEL LLENADO DE LA ETIQUETA PARA CAJAS

Logo Ministerio.jpg

(

Proyecto de Investigación Arqueológica Necrópolis de Ancón, temporada 2016

N° CAJA / TOTAL

1/10

Director(es)

Lic. Juan

Resolución de autorización

Resolución Directora N° 123-2016/DGPA/VMPCIC/MC

Fecha de Resolución

12 de enero de 2016

PROCEDENCIA

Región

Provincia

Distrito

Lima

Lima

Ancón

Sitio

Sector

Área/Unidad/Pozo

Contexto

Ancón

Necrópolis

Pozo 1

IDENTIFICACIÓN

Material

Total de bolsas

Códigos

Peso total (kg)

Cerámica

5

ANC-01 – ANC-05

8

Observaciones

EJEMPLO DEL LLENADO DE LA ETIQUETA INDIVIDUAL

Logo Ministerio.jpg

(Logotipo del proyecto)

Proyecto de Investigación Arqueológica Necrópolis de Ancón,

N° de caja

1

N° de bolsa

1

Código

ANC-01

Denominación

Fragmentos

Material

Cerámica

Cantidad

20

Peso (g)

500

Descripción

15 fragmentos diagnósticos y 5 fragmentos no diagnósticos

Sitio

Ancón

Sector

Necrópolis

Área/Unidad/Pozo

Pozo 1

Capa/UE

1

Nivel

A

Cuadrícula

Contexto

Rasgo/elemento

Fecha

12/01/2016

Excavado por

J. C. T.

Registrado por

L. G. L.

ANEXO 2

FORMATO DE INVENTARIO GENERAL DE BIENES CULTURALES MUEBLES

EJEMPLO DEL LLENADO DEL INVENTARIO GENERAL DE BIENES CULTURALES MUEBLES

ANEXO 3

EJEMPLOS DE VISTAS PARA EL REGISTRO FOTOGRÁFICO DE LOS BIENES MUSEABLES

I:\DIPM - Inventario Nacional de Bienes Culturales Muebles\Museos\Museo Regional de Casma Max Uhle\INVENTARIO COMPLETO\FOTOS\Max Uhle MRCMU-19098 MRCMU-23747\MRCMU-21274.JPG

I:\DIPM - Inventario Nacional de Bienes Culturales Muebles\Museos\Museo Regional de Casma Max Uhle\INVENTARIO COMPLETO\FOTOS\Max Uhle MRCMU-23748  MRCMU-26597\MRCMU-25621.jpg

C:\Users\rloli\Desktop\MRCMU-00189.jpg

I:\DIPM - Inventario Nacional de Bienes Culturales Muebles\Museos\Museo Regional de Casma Max Uhle\INVENTARIO COMPLETO\FOTOS\Max Uhle MRCMU-19098 MRCMU-23747\MRCMU-20861.JPG

I:\DIPM - Inventario Nacional de Bienes Culturales Muebles\Museos\Museo Regional de Casma Max Uhle\INVENTARIO COMPLETO\FOTOS\Max Uhle MRCMU-23748  MRCMU-26597\MRCMU-25720.jpg

I:\DIPM - Inventario Nacional de Bienes Culturales Muebles\Museos\Museo Regional de Casma Max Uhle\INVENTARIO COMPLETO\FOTOS\Max Uhle  MRCMU- 0001 MRCMU-19097\MRCMU-18979.JPG

I:\DIPM - Inventario Nacional de Bienes Culturales Muebles\Museos\Museo Regional de Casma Max Uhle\INVENTARIO COMPLETO\FOTOS\Max Uhle  MRCMU- 0001 MRCMU-19097\MRCMU-18865.JPG

I:\DIPM - Inventario Nacional de Bienes Culturales Muebles\Museos\Museo Regional de Casma Max Uhle\INVENTARIO COMPLETO\FOTOS\Max Uhle  MRCMU- 0001 MRCMU-19097\MRCMU-18875.JPG

ANEXO 4

MODELO DE ACTA DE ENTREGA Y RECEPCIÓN DE BIENES CULTURALES MUEBLES

Logo Ministerio.jpg

ACTA DE ENTREGA Y RECEPCIÓN DE BIENES CULTURALES MUEBLES

ACTA N°

Hora:

Fecha:

Lugar:

Dirección:

Por parte del Proyecto

Por parte del Ministerio de Cultura

Bienes culturales muebles

Nombre

Director

N° y fecha de

Documento que indique el destino final de los

N° cajas:

N° bolsas:

Peso total (kg):

Documentación que se adjunta

a. Inventario general de bienes culturales muebles (impreso y en formato .xls)

b. Archivo fotográfico de los bienes culturales muebles museables (formato .jpg)

c. Etiquetas (formato xls. o .doc)

d. Informe y fichas de intervención de bienes culturales muebles (formato .pdf)

Observaciones

En señal de

Por parte del Ministerio de Cultura

Por parte del Proyecto

EJEMPLO DEL LLENADO DEL ACTA DE ENTREGA Y RECEPCIÓN DE BIENES CULTURALES MUEBLES

Logo Ministerio.jpg

ACTA DE ENTREGA Y RECEPCIÓN DE BIENES CULTURALES MUEBLES

ACTA N°

Hora

Fecha

Lugar: Museo Nacional

Dirección:

Por parte del Proyecto

Por parte del Ministerio de Cultura

Bienes culturales muebles

Nombre del Proyecto:

Director

N° y fecha de

Documento que indique el destino final de los

N° cajas: 10

N° bolsas: 150

Peso total (kg): 45

Documentación que se adjunta

a. Inventario general de bienes culturales muebles (impreso y en formato .xls)

x

x

b. Archivo fotográfico de los bienes culturales muebles museables (formato .jpg)

c. Etiquetas (formato xls. o .doc)

x

d. Informe y fichas de intervención de bienes culturales muebles (formato .pdf)

x

Observaciones

En señal de conformidad suscriben

Lic. Marcos

Lic. Juan

Por parte del Ministerio de Cultura

Por parte del Proyecto

ANEXO 5

GLOSARIO

1. Análisis de flotación3

3 Pearsall 1989

4 Bahn y Renfrew 2016

5 ICOM-CC 2008

6 Lumbreras 1982

7 Bahn y Renfrew 2016

8 Manual de Procedimientos en el Sistema Informatizado de Registro de Bienes Muebles Integrantes del Patrimonio Cultural de la Nación

9 Real Academia de la Lengua Española

10 Ibid.

Técnica de recuperación de restos orgánicos de la matriz del suelo empleando las diferencias de densidad.

2. Artefacto4

Objeto modificado por acción humana, a través de la manufactura o uso.

3. Cartón plástico corrugado

Plancha formada por láminas de polipropileno en la que al menos una está dispuesta en forma de onda, produciendo conductos interiores que la atraviesan y le confieren resistencia a la compresión.

4. Conservación preventiva5

Todas aquellas medidas y acciones que tengan como objetivo eliminar o disminuir los riesgos externos que pueden producir deterioro en los bienes culturales. Se realizan sobre el área circundante al objeto. Son acciones indirectas, no interfieren con los materiales y estructura de los objetos y no modifican su apariencia.

5. Contexto6

Conjunto de elementos y rasgos que aparecen juntos, entendiéndose como elementos a los restos materiales y rasgos a los aspectos formales que particularizan su comportamiento. Son contextos, por ejemplo, una tumba, una capa de basura, el piso de una vivienda, el altar de un templo, un depósito de ofrendas, etc.

6. Coprolito7

Excremento fosilizado que contiene residuos de alimentos empleados para reconstruir la dieta y actividades de subsistencia.

7. Denominación8

Nombre o título con el que se identifica el bien cultural.

8. Depósito, gabinete o laboratorio9

Ambientes acondicionados para el almacenamiento, documentación y análisis de carácter científico.

9. Inerte10

Material inactivo, que no reacciona.

10. Inorgánico11

11 Madrona 2015

12 Artículo 10 del Reglamento de Intervenciones Arqueológicas

13 Manual de Procedimientos en el Sistema Informatizado de Registro de Bienes Muebles Integrantes del Patrimonio Cultural de la Nación

14 Madrona 2015

15 Ibid.

16 Ibid.

17 Ibid.

18 Real Academia de la Lengua Española

Material carente de vida y de los compuestos que a esta la caracterizan.

11. Intervención arqueológica12

Comprende la investigación con fines científicos, el registro, el análisis, la evaluación, el rescate, la determinación de potencialidad, el monitoreo de obras, la conservación preventiva y la puesta en valor, o cualquier combinación de estas modalidades u otras actividades que se empleen en bienes arqueológicos, muebles o inmuebles, con intervención física o no de los mismos.

12. Material13

Clasificación primigenia de los objetos arqueológicos que corresponde al soporte del que está elaborado.

13. Objetos de gran formato

Artefactos de grandes dimensiones y peso.

14. Orgánico14

Sustancia que contiene carbono, formado de manera natural.

15. pH15

Unidad de medida de la concentración de iones hidrógeno, es decir, de átomos de hidrógeno cargados positivamente, que oscila entre 1 y 14. Un pH inferior a 7 se considera ácido y si es superior a 7 básico o alcalino. El pH 7 es neutro y lo constituyen los compuestos que no son ácidos ni bases.

16. Polietileno16

Polímero sintético termoplástico que constituye la base química de muchos plásticos de uso común. Son originados por la polimerización de la olefina, como el etileno. Son resistentes a la humedad.

17. Polipropileno17

Polímero sintético termoplástico muy resistente a altas temperaturas, a diversos solventes químicos, así como contra álcalis y ácidos. Suele presentarse como un plástico translúcido de tono blancuzco.

18. Reversible18

Material que puede volver a su estado o condición original.

19. Tubos de microcentrífuga

Conocidos como tubos Eppendorf. Su tamaño oscila entre los 200 microlitros () y los 2 mililitros (). (https://www.eppendorf.com/ES-es/aplicaciones/physiocare/productos/tubos/)

ANEXO 6

REFERENCIAS

Bahn, P. y Renfrew. C. (2016). Archaeology: Theories Methods and Practice. (7.a ed.). Londres: Thames and Hudson.

Pearsall, D. (1989). Paleoethnobotany: A handbook of procedures. New York: Academic Press.

Comité Internacional del Consejo Internacional de Museos [ICOM-CC]. (2008). Terminología para definir la conservación del patrimonio cultural tangible, Resolución adoptada por los miembros de ICOM-CC durante la 15ª Conferencia Trienal, New Delhi. Recuperado de: https://ge-iic.com/files/Cartasydocumentos/2008_Terminologia_ICOM.pdf

Dirección de Museos y Bienes Muebles. (2013). Manual de procedimientos en el Sistema de Registro del Patrimonio Cultural de la Nación. Lima: Ministerio de Cultura.

Lumbreras L. (1982), Tres principios, tres criterios y tres factores. Gaceta Arqueológica Andina 4-5: 3-10. Lima: Instituto de Estudios Arqueológicos.

Madrona, J. (2015). Vademécum del conservador terminología aplicada a la conservación del patrimonio cultural. Madrid: Editorial Tecnos.

Museo de Sitio Pachacamac. (2019). Protocolo para la recepción de bienes culturales muebles. [documento en pdf]. Recuperado de: http://pachacamac.cultura.pe/sites/default/files/protocolorecepcionmaterial_maco-6_mayo_2019.pdf

Museo Nacional de Costa Rica. (2016). Manual de normas y procedimientos para el tratamiento y el manejo de las colecciones arqueológicas con contexto. San José: Museo Nacional de Costa Rica.

Real Academia Española. (2014). Diccionario de la Lengua Española. (23.a ed.). Barcelona: Espasa Libros.

Scichilone, G. (1990). Almacenaje in situ de los hallazgos. En N. Stanley (Ed.), La conservación en excavaciones arqueológicas (pp. 63-70). Santiago: Centro Nacional de Conservación y Restauración de la Dirección de Bibliotecas, Archivos y Museos.

UNESCO (2010). Manual de Protección del Patrimonio Cultural N° 5. La manipulación de las colecciones almacenadas. Paris: UNESCO.

