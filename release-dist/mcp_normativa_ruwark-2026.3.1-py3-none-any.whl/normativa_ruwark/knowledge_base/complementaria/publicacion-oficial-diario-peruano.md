# Publicación Oficial — Diario Oficial El Peruano

> **Tipo:** Publicación Oficial
> **Número:** Diario Oficial
> **Fecha:** —
> **Estado:** Vigente

---

FUNDADO EL 22 DE OCTUBRE DE 1825 POR EL LIBERTADOR SIMN BOLVAR

"AO DEL FORTALECIMIENTO DE LA SOBERANA NACIONAL" Miércoles 23 de noviembre de 2022

DECRETO SUPREMO Nº 011-2022-MC

DECRETO SUPREMO QUE APRUEBA EL REGLAMENTO DE INTERVENCIONES ARQUEOLÓGICAS

EL PRESIDENTE DE LA REPÚBLICA

CONSIDERANDO:

Que, el primer párrafo del artículo 21 de la Constitución Política del Perú, prescribe que los yacimientos y restos arqueológicos, construcciones, monumentos, lugares, documentos bibliográficos y de archivo, objetos artísticos y testimonios de valor histórico, expresamente declarados bienes culturales, y provisionalmente los que se presumen como tales, son Patrimonio Cultural de la Nación, independientemente de su condición de propiedad privada

o pública. Están protegidos por el Estado;

Que, el artículo 4 de la Ley Nº 29565, Ley de creación del Ministerio de Cultura, establece entre las áreas programáticas de acción del Ministerio de Cultura, las vinculadas al Patrimonio Cultural de la Nación, sobre las cuales ejerce competencia, funciones y atribuciones;

Que, conforme a lo dispuesto en el artículo 5 de la citada norma es competencia exclusiva del Ministerio de Cultura en su condición de organismo rector en materia de cultura, respecto de otros niveles de gobierno en todo el territorio nacional, el dictado de normas y lineamientos técnicos para la adecuada ejecución y supervisión de la política sectorial, así como la aplicación de las políticas nacionales en materia de cultura considerando a los gobiernos regionales, gobiernos locales y organismos privados que operan en el campo de la cultura;

Que, además, la referida norma dispone en el artículo 7 que es función exclusiva del Ministerio de Cultura, respecto de otros niveles de gobierno, entre otras, realizar acciones de declaración, generación de catastro, delimitación, actualización catastral, investigación, protección, conservación, puesta en valor, promoción y difusión del Patrimonio Cultural de la Nación; así como cumplir y hacer cumplir el marco normativo relacionado con el ámbito de su competencia;

Que, el artículo II del Título Preliminar de la Ley Nº 28296, Ley General del Patrimonio Cultural de la Nación, define el bien integrante del Patrimonio Cultural de la Nación como toda manifestación del quehacer humano, material

o inmaterial, que por su importancia, valor y significado arqueológico, arquitectónico, histórico, artístico, militar, social, antropológico, tradicional, religioso, etnológico, científico, tecnológico o intelectual, sea expresamente declarado como tal o sobre el que exista la presunción legal de serlo, teniendo dichos bienes la condición de propiedad pública o privada con las limitaciones que establece la citada Ley;

Que, asimismo, el artículo IV del Título Preliminar de la Ley Nº 28296, Ley General del Patrimonio Cultural de la Nación, dispone que es de interés social y de necesidad pública la identificación, generación de catastro, delimitación, actualización catastral, registro, inventario, declaración, protección, restauración, investigación, conservación, puesta en valor y difusión del Patrimonio Cultural de la Nación y su restitución en los casos pertinentes;

Que, conforme a lo dispuesto en el artículo V del Título Preliminar de la citada norma, los bienes integrantes del Patrimonio Cultural de la Nación, independientemente de su condición privada o pública, están protegidos por el Estado y sujetos al régimen específico regulado en la citada Ley; precisa también que el Estado, los titulares de derechos sobre dichos bienes y la ciudadanía en general tienen la responsabilidad común de cumplir y vigilar el debido cumplimiento del régimen legal desarrollado en la Ley, y dispone además, que el Estado promoverá la participación activa del sector privado en la conservación, restauración, exhibición y difusión de los bienes integrantes del Patrimonio Cultural de la Nación;

Que, a través de la Política Nacional de Cultura al 2030, aprobada mediante el Decreto Supremo Nº 009-2020-MC, se han establecido objetivos prioritarios que concretarán las intervenciones del sector, siendo uno de ellos el Objetivo Prioritario Nº 5 vinculado a fortalecer la protección y salvaguardia del patrimonio cultural para su uso social;

Que, el artículo 5 del Reglamento de la Ley Nº 28296, Ley General del Patrimonio Cultural de la Nación, aprobado por Decreto Supremo Nº 011-2006-ED, establece que el Ministerio de Cultura tiene entre sus atribuciones, la prerrogativa para dictar las normas necesarias para la gestión y uso sostenible del patrimonio cultural y, en consecuencia, para el registro, declaración, protección, identificación, inventario, inscripción, investigación, conservación, difusión, puesta en valor, promoción y restitución en los casos que corresponda, y aprobar las normas administrativas necesarias para ello;

Que, el artículo 28 del precitado reglamento establece que la autorización para intervenir en bienes culturales inmuebles se rige por las disposiciones generales establecidas en la Ley Nº 28296, Ley General del Patrimonio Cultural de la Nación, dicho reglamento y las disposiciones que se expidan sobre la materia;

Que, mediante el Decreto Supremo Nº 003-2014-MC, se aprueba el Reglamento de Intervenciones Arqueológicas, el cual resulta necesario que sea actualizado, en el marco de las disposiciones legales dictadas por el Estado, las cuales están orientadas a la simplificación de los procedimientos administrativos para el beneficio general de la población;

Que, en tal sentido, es necesario aprobar un nuevo Reglamento de Intervenciones Arqueológicas a fin de simplificar y .exibilizar los procedimientos administrativos en beneficio de los administrados, así como establecer procedimientos acordes con los principios regulados por la Ley Nº 27444, Ley del Procedimiento Administrativo General, cuto Texto Único Ordenado ha sido aprobado por Decreto Supremo Nº 004-2019-JUS;

De conformidad con lo dispuesto en la Constitución Política del Perú; el Texto Único Ordenado de la Ley Nº 27444, Ley General del Procedimiento Administrativo General, aprobado mediante el Decreto Supremo Nº 004­2019-JUS; la Ley Nº 28296, Ley General del Patrimonio Cultural de la Nación; la Ley Nº 29565, Ley de creación del Ministerio de Cultura; el Decreto Supremo Nº 011-2006- ED, Decreto Supremo que aprueba el Reglamento de la Ley Nº 28296, Ley General del Patrimonio Cultural de la Nación; y el Decreto Supremo Nº 005-2013-MC, Decreto Supremo que aprueba el Reglamento de Organización y Funciones del Ministerio de Cultura;

DECRETA:

#### Artículo 1.-Aprobación del Reglamento de Intervenciones Arqueológicas

Apruébase el Reglamento de Intervenciones Arqueológicas, que como anexo forma parte integrante del presente decreto supremo, el mismo que consta de un Título Preliminar, siete Títulos, diez Capítulos, y cincuenta y seis artículos.

#### Artículo 2.- Financiamiento

La implementación de lo previsto en el presente decreto supremo se financia con cargo al presupuesto institucional del Ministerio de Cultura, sin demandar recursos adicionales al Tesoro Público.

#### Artículo 3.- Publicación

El presente decreto supremo y el anexo se publican en la sede digital del Ministerio de Cultura (www.gob.pe/ cultura), el mismo día de la publicación de la presente norma en el diario oficial "El Peruano".

#### Artículo 4.- Refrendo

El presente decreto supremo es refrendado por la Ministra de Cultura.

### DISPOSICIONES COMPLEMENTARIAS FINALES

Primera.- De las acciones de emergencia

Las disposiciones del Reglamento de Intervenciones Arqueológicas no resultan aplicables a las acciones de emergencia ejecutadas de oficio por los órganos competentes del Ministerio de Cultura en bienes inmuebles prehispánicos, las mismas que son reguladas de acuerdo con la normativa correspondiente.

Segunda.-Expedición de Certificados de Inexistencia de Restos Arqueológicos en Superficie automáticos

En caso de resoluciones que aprueban el informe de resultados de un Proyecto de Evaluación Arqueológica que hayan sido emitidas antes de la entrada en vigencia del presente reglamento, el administrado puede solicitar la expedición de Certificado de Inexistencia de Restos Arqueológicos en Superficie de manera automática siempre que así se indique en dicha resolución. Para tal efecto, se debe indicar el número y la fecha de resolución.

Tercera.- Disposiciones para los procedimientos administrativos en trámite

Los procedimientos administrativos que se encuentren en trámite en el Ministerio de Cultura se tramitan con las disposiciones con las que se iniciaron hasta su culminación.

Cuarta.-Intervenciones arqueológicas institucionales

El Ministerio de Cultura en cumplimiento de sus objetivos institucionales, puede ejecutar intervenciones arqueológicas aplicando las normas señaladas en el presente reglamento. Los arqueólogos del Ministerio de Cultura pueden dirigir estas intervenciones arqueológicas, conforme a las disposiciones técnicas, administrativas y laborales de la entidad.

Quinta.- De los criterios para la categorización de los bienes inmuebles prehispánicos

El Ministerio de Cultura establece los criterios para la categorización de los bienes inmuebles prehispánicos en un plazo que no exceda los noventa días hábiles, así como las demás normas complementarias que se requieran para la aplicación de lo dispuesto en el Reglamento de Intervenciones Arqueológicas.

Sexta.- Aprobación de normas complementarias

Facúltase al Ministerio de Cultura a expedir, por resolución ministerial, las disposiciones complementarias que resulten necesarias para el correcto desarrollo de los alcances del Reglamento de Intervenciones Arqueológicas.

### DISPOSICIÓN COMPLEMENTARIA DEROGATORIA

Única.- Derogación

Derógase el artículo 2 y la Primera Disposición Complementaria Final del Decreto Supremo Nº 054-2013­PCM; el segundo párrafo de la Segunda Disposición Complementaria Final, la Primera, la Tercera y la Cuarta Disposición Complementaria Transitoria del Decreto Supremo Nº 060-2013-PCM; el Decreto Supremo Nº 003­2014-MC, Decreto Supremo que aprueba el Reglamento de Intervenciones Arqueológicas; así como toda aquella norma que se oponga al presente reglamento.

Dado en la Casa de Gobierno, en Lima, a los veintidós días del mes de noviembre del año dos mil veintidós.

JOSÉ PEDRO CASTILLO TERRONES

Presidente de la República

BETSSY BETZABET CHAVEZ CHINO

Ministra de Cultura

REGLAMENTO DE INTERVENCIONES ARQUEOLÓGICAS

## TÍTULO PRELIMINAR

Artículo I. Objeto

El Reglamento de Intervenciones Arqueológicas – RIA, tiene por objeto regular los aspectos técnicos y administrativos referidos a la ejecución de intervenciones arqueológicas a nivel nacional en sus diversas modalidades, la emisión del Certificado de Inexistencia de Restos Arqueológicos en Superficie - CIRAS y la constancia de antecedentes catastrales arqueológicos, así como la gestión de materiales culturales muebles e inmuebles y la exportación de muestras arqueológicas con fines de investigación científica recuperadas en el ámbito de las intervenciones arqueológicas.

Artículo II. Política y principios generales

1.

Los bienes integrantes del Patrimonio Cultural de la Nación son reconocidos como recursos culturales frágiles y no renovables, por lo que el fomento de su estudio a través de la investigación arqueológica, declarada como de interés social y de necesidad pública según la Ley No 28296, Ley General del Patrimonio Cultural de la Nación, es considerado de prioritaria importancia, su conservación es reconocida como de interés nacional, y su inclusión en las políticas de desarrollo nacional, regional y local es concebida como estratégica. Estos bienes están protegidos por el Estado.

2.

Todos los bienes inmuebles integrantes del Patrimonio Cultural de la Nación de carácter prehispánico

son propiedad del Estado, así como sus partes integrantes y/o accesorias, y sus componentes descubiertos o por descubrir, independientemente que se encuentren ubicados en predios de propiedad pública o privada.

3.

El Ministerio de Cultura, en el ejercicio de sus competencias de protección y conservación, promoción y difusión de los bienes materiales con valor arqueológico integrantes del Patrimonio Cultural de la Nación, es el único ente encargado de regular la condición de intangible de dichos bienes, y de autorizar toda intervención arqueológica a través de lo normado en el presente reglamento.

4.

Todas las intervenciones arqueológicas que se realicen en territorio nacional se sujetan a los estándares científicos, a las leyes y normas de protección del patrimonio cultural. Las intervenciones se ejecutan y cumplen con las acciones de identificación, registro, investigación científica, conservación, protección, difusión, y puesta en valor del Patrimonio Cultural de la Nación.

5.

El Estado, a través del Ministerio de Cultura, es el encargado de integrar y armonizar el pasado con el presente y el futuro del país, salvaguardando el patrimonio cultural. Con este fin, el presente reglamento se fundamenta en los siguientes principios:

a) Principio de máxima protección del Patrimonio Cultural de la Nación:

La Constitución Política del Perú impone el deber de brindar la máxima protección a nuestro patrimonio cultural,

a efectos de garantizar su valor intrínseco que dota de identidad y unidad a nuestra nación (interés general).

En ese sentido toda persona o autoridad frente a cualquier duda o vacío normativo vinculado a las prerrogativas, metodologías y en general cualquier medida que impacte a bienes inmuebles prehispánicos, que se genere en el marco de la aplicación de las intervenciones arqueológicas y procedimientos conexos que regula el presente reglamento, debe orientar y optar por aquellas medidas que garanticen y brinden la mayor protección a dichos bienes; entendiéndose como máxima protección del Patrimonio Cultural de la Nación al curso de acción que debe seguir toda persona o autoridad para la protección de los bienes inmuebles prehispánicos.

b) Principio de garantía del ejercicio de derechos culturales:

El Estado garantiza el acceso, la participación y contribución a la vida cultural para la sociedad, que involucra el conocimiento y reconocimiento de nuestra identidad cultural a través del acceso, disfrute y conocimiento de los valores de los bienes arqueológicos. Para ello, impulsa la investigación arqueológica y la difusión de sus resultados, la conservación, la puesta en valor y el uso social sostenible de los bienes arqueológicos; además, promueve y vela para que toda actividad antrópica que concierna a bienes arqueológicos se realice conforme al marco normativo vigente.

c) Principio de sostenibilidad:

Los bienes inmuebles prehispánicos deben de tener un manejo y uso adecuado que permita garantizar su investigación, conservación, acondicionamiento, acceso, disfrute y aprendizaje para la presente y futuras generaciones, mediante su gestión que tiene como meta brindar el servicio de interpretación cultural a la ciudadanía, a fin de revelar, difundir y sensibilizar los valores y significados de los bienes inmuebles prehispánicos para contribuir a su conocimiento, valoración y el fortalecimiento de la identidad cultural de la ciudadanía.

d) Principio de impulso a la producción científica e innovación tecnológica:

Toda intervención arqueológica se orienta, en esencia, a la producción científica y/o a la obtención de datos científicos contextualizados, para tal efecto, el Ministerio de Cultura promueve la innovación en la investigación arqueológica propendiendo e incorporando el uso de nuevas tecnologías de investigación e intervención arqueológica.

Artículo III. Ámbito de aplicación

Las disposiciones contenidas en el presente reglamento, sus modalidades y formalidades, son de aplicación obligatoria para las personas naturales y/o jurídicas públicas o privadas, que ejecuten intervenciones arqueológicas a nivel nacional en sus diversas modalidades, que soliciten la emisión del Certificado de Inexistencia de Restos Arqueológicos en Superficie - CIRAS y la constancia de antecedentes catastrales arqueológicos, así como la gestión de materiales culturales muebles e inmuebles y la exportación de muestras arqueológicas con fines de investigación científica recuperadas en el ámbito de las intervenciones arqueológicas en todo el territorio nacional, incluso para aquellas que estuvieran a cargo del Ministerio de Cultura.

Artículo IV. Competencia

El Ministerio de Cultura elabora, aprueba y ejecuta los lineamientos y directivas en materia de intervenciones arqueológicas, en concordancia con las políticas de Estado y con los planes sectoriales y regionales. Asimismo, vela por el cumplimiento de las normas contenidas en el presente reglamento.

El Ministerio de Cultura ejerce competencia sobre el Patrimonio Cultural de la Nación, de conformidad con lo establecido en la Constitución Política del Perú y el ordenamiento jurídico vigente. Las Direcciones Desconcentradas de Cultura son las responsables de actuar en representación del Ministerio de Cultura dentro de sus ámbitos territoriales y en estricto cumplimiento de las disposiciones y los lineamientos que el Ministerio emita.

Artículo V. Definiciones

Para efectos de la aplicación de las disposiciones contenidas en el presente reglamento, se entiende por:

1.

Acta de inspección.-Es el formato establecido por el Ministerio de Cultura que es utilizado por el inspector durante las inspecciones oculares de las diferentes modalidades de intervenciones arqueológicas, y su elaboración es condición necesaria para la evaluación de los resultados.

2.

Carácter ineludible.-Es aquella condición que determina que la ejecución de una obra pública o privada que comprometa un bien cultural mueble o inmueble con valor arqueológico resulta inevitable. Esta condición debe contar necesariamente con un sustento técnico que fundamente que la obra no puede ser desarrollada en un espacio distinto al propuesto.

3.

Delimitación.-Es el procedimiento técnico que determina, la extensión de un bien inmueble prehispánico, incluyendo su marco circundante, la cual se representa gráficamente a través de un polígono.

4.

Director.- Es el profesional en arqueología que elabora, diseña y formula una intervención arqueológica, siendo responsable de la ejecución del plan de trabajo de dicha intervención.

5.

Elemento Arqueológico Aislado.- Es la evidencia de actividad humana prehispánica que, por procesos naturales, culturales y/o antrópicos modernos, se encuentra de manera aislada y descontextualizada. Comprende bienes inmuebles como las evidencias de estructuras fragmentadas, así como bienes muebles como piezas aisladas y/o fragmentería cerámica dispersa, material malacológico disperso, u otro material cultural.

6. Impactos al patrimonio arqueológico.-Situaciones originadas por acciones y/o actividades de las obras, proyectos o planes de desarrollo, de cualquier magnitud e índole que pueden modificar la integridad física y el aspecto visual de un bien inmueble prehispánico (en la superficie, el subsuelo o medio subacuático, en los aires, y en el marco circundante), por ubicarse dentro del área de influencia directa y/o indirecta de los mismos. Este concepto solo se aplica en el contexto de los procedimientos debidamente evaluados y autorizados por el Ministerio de Cultura (PEA, PRA, PMAR), con el fin de mitigar los impactos negativos que pueden producirse en el patrimonio arqueológico durante la ejecución de planes, proyectos u obras de desarrollo.

7. Infraestructura preexistente.-Es todo tipo de construcción u obra de carácter permanente, que se encuentra edificada o instalada en el suelo o subsuelo, exceptuándose de dicho concepto a las instalaciones que, de acuerdo con las características del proyecto, se consideran temporales (canteras, depósitos de material excedente, campamentos, etc.). Se incluye al área o extensión correspondiente al derecho de vía y/o servidumbre, acorde al acto administrativo emitido por la autoridad competente, siempre y cuando no se superponga a un bien inmueble prehispánico ni atente de manera directa o indirecta contra el Patrimonio Cultural de la Nación. En los casos que no se haya establecido según norma las dimensiones del derecho de vía y/o servidumbre, la infraestructura preexistente será verificada previa inspección del Ministerio de Cultura.

8.

Intangible.-Es aquella condición regulada de los bienes inmuebles prehispánicos integrantes del Patrimonio Cultural de la Nación que consiste en conservar su integridad, encontrándose sujeta a las intervenciones autorizadas por el Ministerio de Cultura sustentada en los fines que señala el presente reglamento, como la investigación, evaluación, rescate, monitoreo, emergencia, así como delimitación, actualización catastral, saneamiento, identificación, inventario, inscripción, registro, protección, difusión, promoción, puesta en valor, gestión y administración.

9.

Marco Circundante.-Es el espacio que envuelve o rodea la zona nuclear de un bien inmueble prehispánico. Su principal función es de la proteger, física y visualmente, las evidencias muebles o inmuebles del bien inmueble prehispánico, precisadas en su área nuclear, limitando su uso a actividades compatibles con la gestión patrimonial u otras propias con su conservación. El marco circundante forma parte del polígono de delimitación de un bien inmueble prehispánico. El marco circundarte tiene también la condición de intangible.

10.

Medidas de mitigación.-Son el conjunto de procedimientos técnicos orientados a mitigar en lo posible los potenciales impactos negativos sobre los bienes inmuebles prehispánicos comprometidos a través de una obra, proyecto o plan de desarrollo. Estas medidas deben formar parte de los Programas de Responsabilidad Social, Planes de Manejo Ambiental y/u otros instrumentos ambientales, de las empresas titulares de las obras, proyectos o planes de desarrollo que originan el impacto.

11.

Potencial arqueológico.-Es la ponderación técnica de los criterios de singularidad, complejidad y factores de riesgo, además de la importancia histórica del bien y el significado de éste para la comunidad.

12.

Puesta en valor.- Son todas las gestiones y acciones técnicas, administrativas, sociales y operativas que se realizan de manera previa, durante y/o luego de intervenir un bien inmueble prehispánico, ya sea a través de una intervención arqueológica, o mediante la implementación de servicios culturales y usos compatibles, a fin de difundir y poner en valor el Patrimonio Cultural de la Nación. La puesta en valor vincula la historia del bien, la cultura del lugar, y el mensaje que ese bien debe transmitir al visitante.

13.

Retiro de condición de Patrimonio Cultural de la Nación de los bienes inmuebles prehispánicos.-Es el acto resolutivo emitido por la autoridad competente como resultado de la evaluación del procedimiento por el cual se fundamenta la pérdida, total o parcial, del bien inmueble prehispánico declarado, en uno o más de sus valores culturales que sustentaron su condición como Patrimonio Cultural de la Nación, atribuibles a factores naturales o antrópicos.

14.

Titular.-Es la persona natural o jurídica a cuyo favor se emite la autorización para la ejecución de una intervención arqueológica o para la gestión de materiales culturales, o para la exportación de muestras, o a cuyo favor se emite los CIRAS y la constancia de antecedentes arqueológicos.

Para el caso de las intervenciones arqueológicas, el titular de la autorización, el director de la intervención arqueológica, y todos los sujetos intervinientes en la ejecución de dicha intervención, conforman una sola parte administrada que, en consecuencia, fija un único domicilio común para efectos de diligenciar toda notificación relacionada a los procedimientos administrativos regulados por el presente reglamento.

15.

Uso compatible.-Es aquel uso moderno que respeta la integridad y autenticidad del bien inmueble prehispánico.

16. Uso tradicional.-Es aquel uso moderno que sin poner en riesgo la integridad estructural y arquitectónica de algunos componentes de un paisaje arqueológico, pueden seguir siendo utilizados de forma restringida, conforme a su función original y tradicional, como en los casos de andenes, terrazas, canales, camellones, e infraestructura vial prehispánica.

En los alcances de esta definición, se considera a las actividades económicas y/o productivas o de culto que realizan los pueblos indígenas u originarios al interior de las áreas delimitadas de un bien inmueble prehispánico.

Artículo VI. Clasificación de los bienes inmuebles prehispánicos

Los bienes inmuebles prehispánicos son bienes materiales con valor arqueológico integrantes del Patrimonio Cultural de la Nación, que se intervienen mediante métodos arqueológicos y se clasifican en:

1. Sitio Arqueológico: Es el espacio que contiene evidencias arqueológicas muebles y/o inmuebles asociados entre sí, tanto en superficie como en el subsuelo

o en medio subacuático.

2.

Complejo Arqueológico Monumental: Es el conjunto de bienes inmuebles prehispánicos con un valor singular y excepcional debido a su extensión, monumentalidad y ordenamiento espacial arquitectónico; contiene edificaciones ceremoniales, administrativas, funerarias u otras, y su diseño y fisonomía deben conservarse.

3.

Paisaje Arqueológico: Es el resultado del desarrollo de actividades humanas durante la época prehispánica en un espacio concreto que refleja la interacción con el ecosistema; tiene valor arqueológico, arquitectónico, histórico, científico o artístico. Se considera Paisaje Arqueológico a la infraestructura agrícola tales como andenes, terrazas, canales, camellones y afines, a la infraestructura vial como caminos prehispánicos e itinerarios culturales, así como a los geoglifos, arte en roca y similares. Estos componentes pueden seguir siendo utilizados sin que generen riesgo en su integridad paisajística, estructural y arquitectónica, a excepción de los geoglifos, arte en roca y similar. El Ministerio de Cultura determina las condiciones para garantizar su integridad. Un paisaje arqueológico puede integrar un paisaje cultural.

4.

Reservas y Parques Arqueológicos: Son espacios geográficos de grandes dimensiones que abarcan jurisdicciones políticas en cuyo interior se ubican sitios, complejos y paisajes arqueológicos, los que se relacionan y/o interactúan con áreas de dominio público e infraestructura de desarrollo en general, y que necesitan ser protegidos para su investigación y difusión.

Pueden ser pasibles de saneamiento físico legal, para fines de su gestión, los bienes inmuebles prehispánicos (sitios, complejos y paisajes arqueológicos) ubicados al interior de las Reservas y Parques Arqueológicos para lo cual se deberá precisar su delimitación, excluyendo del mismo, áreas de dominio público, accidentes geográficos que puedan ocasionar un riesgo a su debida conservación e infraestructura moderna que no guarde relación con su debida gestión.

## TÍTULO I

INTERVENCIONES ARQUEOLÓGICAS

### CAPÍTULO I

### DISPOSICIONES GENERALES

#### Artículo 1. Generalidades

1.1 Las intervenciones arqueológicas comprenden acciones de investigación, el registro, el análisis, la

conservación, la puesta en valor, y la gestión del bien inmueble prehispánico, y las acciones de arqueología preventiva como la evaluación, el rescate y el monitoreo.

1.2 El Ministerio de Cultura puede ejecutar de oficio intervenciones arqueológicas bajo cualquier modalidad como parte de sus funciones, siempre y cuando dichas intervenciones sean acordes con las políticas, lineamientos y objetivos institucionales de la entidad y cumplan la normativa vigente.

1.3 El presente reglamento, que concierne primordialmente a los bienes del patrimonio cultural inmueble de origen prehispánico, es de aplicación supletoria en intervenciones del patrimonio cultural inmueble de origen histórico y sitios subacuáticos, cuando el tipo de intervención amerite consideraciones metodológicas propias de la arqueología.

1.4 El presente título define los procedimientos administrativos referidos a las distintas modalidades de intervención arqueológica que se ejecutan obligatoriamente en salvaguarda de los bienes inmuebles integrantes del Patrimonio Cultural de la Nación.

1.5 Para la ejecución de intervenciones arqueológicas en medios subacuáticos, las acciones en caso de hallazgos y el tratamiento de los materiales recuperados, deben cumplir los procedimientos y requisitos establecidos por el presente reglamento.

1.6 En ningún caso se autoriza la ejecución de intervenciones arqueológicas en vías de regularización. Tampoco se autorizan intervenciones arqueológicas con fines preventivos (PEA, PRA y PMAR) en áreas donde ya se han iniciado o culminado acciones propias de la obra que motiva la intervención arqueológica.

1.7. Los proyectos de inversión pública y privada e inversiones IOARR que se plani.quen ejecutar al interior de los bienes inmuebles prehispánicos, o que contemplen en su ámbito de influencia directa a los bienes inmuebles prehispánicos colindantes, requieren de la opinión favorable de la Dirección General de Patrimonio Arqueológico Inmueble; de forma previa a la tramitación de la autorización de las modalidades de intervención arqueológica que se requieran.

1.8. Las intervenciones arqueológicas que, debido a las recolecciones y/o excavaciones realizadas, generen la necesidad de almacenamiento de bienes culturales muebles, deben contemplar el pago por almacenamiento de los materiales entregados al Ministerio de Cultura, por lo que, deberá acreditar el pago en la presentación del Informe de Resultados de las intervenciones arqueológicas, según corresponda.

1.9. En caso que, por razones imputables al titular y/o el director de la intervención arqueológica, el Ministerio de Cultura, a través de sus órganos competentes, se vea impedido de ejercer su competencia de inspeccionar la correcta ejecución de la intervención arqueológica, se evidencie entorpecimiento para el acceso a información vinculada a los bienes culturales inmersos en la intervención arqueológica, o de cualquier forma se advierta que la intervención arqueológica afecta o pone en peligro el Patrimonio Cultural de la Nación; independientemente de la no conformidad del Informe de Resultados correspondiente, se comunicará el hecho a la Dirección General de Defensa del Patrimonio Cultural, o quien haga sus veces en las Direcciones Desconcentradas de Cultura, a efectos de evaluar la pertinencia de iniciar procedimiento administrativo sancionador; asimismo se evaluará dicha pertinencia cuando, aun contando con la conformidad de los trabajos de campo, el o los administrados, en el marco del cumplimiento de la obligación de presentar el Informe de Resultados, omiten presentar los datos de campo que sustentan los resultados obtenidos, como el registro fotográfico, diarios de campo, entre otros, según las exigencias que regula el presente reglamento para cada modalidad de intervención arqueológica.

1.10. Cuando por la naturaleza de la int ervención arqueológica, se requiera ampliar su ámbito de ejecución, el administrado puede solicitar la incor poración de las nuevas áreas que sean necesarias para ga rantizar el cumplimiento de los objetivos de la i ntervención arqueológica. El Ministerio de Cultura a probará las disposiciones necesarias para dicho fin. Queda prohibido autorizar la incorporación de nuevas ár eas en vías de regularización.

1.11. En el caso de las solicitudes para ejecutar intervenciones arqueológicas, así como la gestión de materiales culturales muebles e inmuebles y la exportación de muestras arqueológicas con fines de investigación científica, iniciadas de oficio por el Ministerio de Cultura, en el ejercicio de sus funciones y en el marco del cumplimiento de sus objetivos institucionales, no aplica el cobro de tasas por derechos de tramitación.

1.12 Las ordenanzas, resoluciones, acuerdos y reglamentos emitidos por los gobiernos regionales y locales (provinciales y distritales), que tengan implicancia con bienes integrantes del Patrimonio Cultural de la Nación, requieren opinión previa favorable del Ministerio de Cultura, en caso contrario serán nulos de pleno derecho.

#### Artículo 2. Modalidades

Las intervenciones arqueológicas se agrupan en dos modalidades, de acuerdo a su finalidad:

2.1 Intervenciones arqueológicas con fines de investigación, conservación y puesta en valor: Las intervenciones arqueológicas con fines de investigación, conservación y puesta en valor se ejecutan con autorización del Ministerio de Cultura. Estas intervenciones buscan generar conocimiento científico, mediante la ejecución de un programa o proyecto de investigación, el cual contiene el marco teórico, las hipótesis de investigación, el objetivo general y los objetivos específicos, aplicando los métodos y principios propios de la disciplina arqueológica. El resultado de las investigaciones constituye un insumo para la conservación, el conocimiento, la difusión, la puesta en valor, la interpretación, el acondicionamiento, y la gestión del bien inmueble prehispánico. Esta modalidad comprende tres tipos de intervenciones arqueológicas:

a) Programas de Investigación Arqueológica – PRIA: Son intervenciones arqueológicas integrales, interdisciplinarias y de larga duración en bienes inmuebles prehispánicos o en una región; su principal objetivo es la producción y difusión de conocimiento científico de las sociedades del pasado mediante la investigación, la conservación, el acondicionamiento, la puesta en valor, y la gestión de los bienes inmuebles prehispánicos. Un Programa de Investigación Arqueológica puede contemplar uno más intervenciones arqueológicas, en diversas modalidades, todo ello en el marco de la puesta en valor del monumento.

b) Proyectos de Investigación Arqueológica – PIA: Son intervenciones arqueológicas puntuales y de corta duración en uno o más bienes inmuebles prehispánicos,

o en una región. Su principal objetivo es la producción y difusión del conocimiento científico de las sociedades del pasado, mediante la investigación. Asimismo, se orientan a la conservación, el acondicionamiento, la puesta en valor y la gestión de los bienes inmuebles prehispánicos.

c) Proyectos Arqueológicos de Emergencia – PAE: Son aquellas intervenciones de recuperación, conservación y/o estabilización de un bien inmueble prehispánico que se encuentra en inminente peligro de daño o alteración (afectación), sea total o parcial. Se realizan con el fin de eliminar y mitigar la alteración o daño causado por agentes naturales y/o actividades humanas, y que no se encuentra en curso.

2.2 Intervenciones arqueológicas con fines preventivos: Son aquellas que se ejecutan con autorización del Ministerio de Cultura, en el marco de proyectos productivos, extractivos, de servicios y/o de infraestructura, ya sean públicos o privados. Tienen el objeto de identificar y mitigar el impacto al patrimonio arqueológico como producto de la ejecución de dichos proyectos. Esta modalidad comprende tres tipos de intervenciones arqueológicas:

a) Proyectos de Evaluación Arqueológica – PEA: Comprenden trabajos de reconocimiento arqueológico al interior del área materia del proyecto de inversión, público o privado, metodológicamente con el objeto de identificar bienes inmuebles prehispánicos, y elementos arqueológicos aislados, procediendo a su registro, estableciendo su extensión mediante la delimitación, señalización, y demarcación física, de ser el caso. Asimismo, se realiza excavaciones restringidas con fines de delimitación, descarte, muestreo y potencialidad. Estas intervenciones tienen como finalidad y objetivo identificar, evaluar, medir, prevenir impactos negativos al Patrimonio Cultural de la Nación, y con ello, determinar las medidas de mitigación necesarias para su salvaguarda.

b) Proyectos de Rescate Arqueológico – PRA: Son intervenciones arqueológicas que ejecutan trabajos de excavación, registro, recuperación y restitución de las evidencias arqueológicas (prehispánicas o históricas), en el área total o en áreas parciales del bien arqueológico inmueble, debido a la ejecución de planes, proyectos u obras públicas o privadas necesarias, cuando el impacto sobre el bien arqueológico inmueble resultara de carácter ineludible por razones técnicas y aquellas declaradas de necesidad y utilidad pública por el Poder Ejecutivo, a propuesta del sector correspondiente.

Los proyectos de rescate arqueológico se derivan de los Proyectos de Evaluación Arqueológica o de los Planes de Monitoreo Arqueológico y son realizados en el marco de proyectos productivos, extractivos, infraestructura y/o servicios tanto en el sector público y privado.

c) Planes de Monitoreo Arqueológico – PMAR: Son intervenciones arqueológicas de carácter preventivo destinadas a evitar, controlar, reducir y mitigar los posibles impactos negativos sobre evidencias arqueológicas que se encuentren de manera fortuita en el subsuelo, y/o sobre los bienes inmuebles prehispánicos colindantes a una obra

o ubicados al interior de su área de influencia ambiental, en el marco de la ejecución de proyectos productivos y extractivos, obras de infraestructura y servicios, e implementación de infraestructura complementaria al Patrimonio Cultural de la Nación, que impliquen remoción del suelo y subsuelo del área materia de intervención. Debe ser tramitado con anterioridad al inicio de la ejecución física de toda obra.

#### Artículo 3. Autorización y titularidad

3.1 Toda intervención arqueológica, ya sea en bienes de dominio público o privado, debe contar con la autorización previa del Ministerio de Cultura.

3.2 Las solicitudes destinadas a la autorización de intervenciones arqueológicas bajo cualquiera de sus modalidades, así como para la ampliación y renovación de la vigencia, o suspensión de plazos, desistimiento, cambio de dirección, transferencia de titularidad, levantamiento de observaciones y demás supuestos procedimentales regulados por el presente reglamento, son tramitadas a través de la plataforma de los servicios en línea del Ministerio de Cultura o en formato físico con versión digital (CD o DVD). Las solicitudes son luego derivadas para su respectiva calificación a cargo de las unidades orgánicas de la Sede Central del Ministerio de Cultura, o de las Direcciones Desconcentradas de Cultura, según el ámbito de sus competencias.

3.3 Las autorizaciones que se emitan al amparo del presente reglamento no otorgan derechos reales sobre el terreno donde se ejecuta la intervención arqueológica ni sobre sus partes integrantes, ni sobre los bienes muebles recuperados en el ámbito de la intervención.

3.4 En el caso de personas jurídicas, la solicitud debe ser suscrita por su representante legal, quien debe acreditar tal condición. La autorización es otorgada a la persona jurídica, la que es considerada titular de la intervención arqueológica, con indicación del director a cargo de ésta.

3.5 La transferencia de la titularidad de una intervención arqueológica puede ser autorizada por el Ministerio de Cultura en los siguientes supuestos:

a)

Ante la imposibilidad acreditada del titular primigenio para proseguir el desarrollo del proyecto.

b)

Cuando la persona jurídica sea objeto de fusión, escisión, compraventa u otros, debidamente acreditada.

c)

Cuando la persona natural acredite la transferencia de los derechos y obligaciones de la intervención arqueológica a una tercera persona.

3.6 El nuevo titular de la intervención arqueológica asume todas las obligaciones y responsabilidades inherentes a la autorización.

#### Artículo 4. Intervenciones arqueológicas en bienes inmuebles prehispánicos administrados por el Ministerio de Cultura

Para realizar intervenciones arqueológicas en los bienes inmuebles prehispánicos administrados por el Ministerio de Cultura, se debe contar con la opinión técnica de los directores y/o responsables de dichos bienes. Esta opinión comprende los siguientes aspectos de la intervención:

a)

Ubicación de las áreas a intervenir.

b)

Metodología a emplearse.

c)

Destino final de las colecciones recuperadas.

Asimismo, durante el desarrollo de la intervención el director del proyecto o programa mantendrá una coordinación constante con el director y/o responsable del bien inmueble prehispánico.

#### Artículo 5. Improcedencia

No se expide autorización a personas naturales y/o jurídicas (titulares y/o directores) en tanto incurran en cualquiera de los siguientes supuestos:

5.1 No haber entregado el informe de resultados, o informe preliminar de ser el caso, de cualquier intervención arqueológica que haya sido previamente autorizada a su favor, dentro del plazo señalado en la resolución de autorización.

5.2 No acreditar la devolución de colecciones otorgadas en custodia y el informe de resultados, dentro del plazo establecido en la resolución de custodia.

5.3 No acreditar la devolución de las muestras entregadas para análisis no destructivos, o de los informes y/o publicaciones derivadas de los análisis, en los plazos establecidos en el artículo 16 de la presente norma.

5.4 Encontrarse sancionado por el Ministerio de Cultura por la comisión de infracciones leves, graves, o muy graves, por afectación de un bien integrante del Patrimonio Cultural de la Nación. Esta restricción se mantiene por el plazo de dos años para las infracciones leves, y de cuatro años para las infracciones graves y seis años para las muy graves, computados a partir de la fecha de notificación de la sanción.

5.5 Haber sido condenado por delito doloso relacionado a la afectación del Patrimonio Cultural de la Nación. Esta restricción se mantiene por el plazo determinado por la sanción penal.

5.6 Las causales de improcedencia señaladas en los numerales 5.1, 5.2 y 5.3 se activan una vez vencido el plazo otorgado para el cumplimiento de su obligación y se mantiene vigente hasta su presentación.

#### Artículo 6. Calificación de la intervención

6.1 Si la solicitud es observada se pone en conocimiento del solicitante, otorgándole un plazo de diez días hábiles a partir del día hábil siguiente de la recepción de la notificación para subsanar las observaciones, dicho plazo puede ser prorrogado por única vez por el término de diez días hábiles adicionales, siempre y cuando se solicite antes de su vencimiento. Si las observaciones persisten, se mantiene la facultad de la administración de requerir única y exclusivamente, la subsanación de las observaciones, en un plazo adicional de diez días hábiles, bajo apercibimiento de denegar la solicitud de autorización del proyecto de intervención arqueológica y/o certificación. En ningún caso se puede realizar nuevas observaciones.

6.2 El procedimiento administrativo queda suspendido desde la recepción de la notificación de las observaciones hasta la presentación de la subsanación de las observaciones formuladas.

6.3 Los actos administrativos que se emitan en el ámbito del presente reglamento son susceptibles de la interposición de los recursos administrativos de reconsideración y apelación, según lo dispuesto en el Texto Único Ordenado de la Ley Nº 27444, Ley del Procedimiento Administrativo General

#### Artículo 7. Desistimiento de la solicitud o renuncia a la autorización

7.1 El titular puede desistirse de la solicitud de autorización de la intervención arqueológica antes de la emisión del respectivo acto administrativo.

7.2 El titular puede renunciar a la autorización concedida a su favor siempre y cuando se acredite que la intervención arqueológica no fue ejecutada.

7.3 La solicitud de desistimiento o renuncia es resuelta por la Dirección de Calificación de Intervenciones Arqueológicas, por la Dirección de Certificaciones, o por las Direcciones Desconcentradas de Cultura, según el ámbito de sus competencias.

#### Artículo 8. Vigencia

8.1 El plazo máximo por el que se otorga la autorización para la ejecución de un PIA, de un PEA o de un PRA, es de un año. El cómputo del plazo está supeditado a la fecha de inicio de la intervención, indicada en el cronograma de trabajo.

8.2 En el caso de un PRIA, la autorización es otorgada por un plazo mínimo de dos años y máximo de cinco años, conforme a lo establecido en el numeral 17.1 del artículo 17 del presente reglamento.

8.3 El plazo por el que se otorga la autorización para la ejecución de un PMAR, está supeditado al cronograma de ejecución de la obra que implique la remoción del suelo y subsuelo del área materia de intervención.

8.4 El plazo máximo por el que se otorga la autorización para la ejecución de un PAE es de ciento ochenta días calendarios.

8.5 Las autorizaciones previamente señaladas en el presente artículo pueden ser ampliadas y renovadas con sujeción a lo señalado en el artículo 30 del presente reglamento.

#### Artículo 9. Suspensión

9.1 El administrado puede solicitar la suspensión de la autorización de la intervención arqueológica por razones de caso fortuito y/o fuerza mayor que impidan o di.culten su normal ejecución. El plazo de suspensión es evaluado y determinado por la autoridad competente y está sujeto a la duración del caso fortuito y/o fuerza mayor.

9.2 Cuando la suspensión de la autorización suponga un riesgo al Patrimonio Cultural de la Nación, el Ministerio de Cultura se reserva la potestad de emplazar al titular de la autorización con el objeto de requerirle la ejecución de acciones específicas de mantenimiento y conservación preventiva. Estas acciones comprenden el apuntalamiento, estabilización y conservación de estructuras, la colocación de techumbres y gaviones, entre otras, destinadas a salvaguardar el Patrimonio Cultural de la Nación, debiendo precisar el modo y los plazos de cumplimiento mediante acto administrativo debidamente motivado.

#### Artículo 10. Revocación

10.1 Las autorizaciones concedidas al amparo del presente reglamento pueden ser revocadas por el Ministerio de Cultura, en tanto concurra cualquiera de los supuestos establecidos en el Texto Único Ordenado de la Ley Nº 27444, Ley del Procedimiento Administrativo General.

10.2 El acto administrativo que declara la revocación de una autorización conlleva al agotamiento de la respectiva vía administrativa.

#### Artículo 11. Dirección y participación

11.1 La dirección de una intervención arqueológica está a cargo de un profesional en arqueología debidamente colegiado y habilitado. El director elabora, diseña y formula la intervención arqueológica, siendo responsable de dirigir y ejecutar el plan de trabajo, así como elaborar el informe de resultados de la intervención arqueológica, conforme a las normas de la materia. Las intervenciones arqueológicas pueden contar con más de un director, con las mismas responsabilidades y atribuciones.

11.2 El director podrá dirigir de forma simultánea cualquier modalidad de intervención arqueológica cuando no se superpongan los cronogramas de la fase de trabajo de campo contenidos en los programas, proyectos y planes autorizados.

11.3 El director permanece durante la totalidad de la fase del trabajo de campo de la intervención arqueológica si ésta no cuenta con un arqueólogo residente.

11.4 Por excepción, el director de un PMAR que derive en un PRA, puede ejercer la dirección de este último, siempre y cuando cuente con un arqueólogo residente en cada intervención arqueológica.

11.5 El director de un PRIA requiere experiencia en la dirección de proyectos de investigación.

11.6 Es procedente la participación de un profesional extranjero como director en los PRIA y PIA, siempre que se cuente con un arqueólogo peruano como codirector; ambos deben estar colegiados y habilitados. Ambos directores son responsables en la formulación y ejecución integral del PRIA y PIA, tanto en campo como gabinete, así como en la elaboración del informe de resultados. Durante la intervención arqueológica en la fase de campo, la permanencia de uno de los codirectores en el bien inmueble prehispánico es obligatoria, debiendo estar siempre acompañado por el arqueólogo residente.

#### Artículo 12. Cambio de director y/o arqueólogo residente

12.1 El titular de la autorización puede solicitar a la autoridad competente que autorizó el cambio de director y/o arqueólogo residente por renuncia, cese de la relación contractual u otro; sustentando el cambio solicitado y proponiendo a un nuevo director y/o arqueólogo residente; propuesta que, en el caso del director, debe ir acompañada de un informe preliminar de los trabajos realizados hasta la fecha por el director renunciante o cesado.

12.2 El nuevo director y/o arqueólogo residente debe cumplir con los requisitos establecidos para la autorización de la intervención arqueológica, así como lo dispuesto en el artículo 11 y no estar incurso en las causales de improcedencia. La autoridad competente que autoriza la intervención arqueológica tiene un plazo de cinco días hábiles para autorizar o denegar la solicitud de cambio de director y/o arqueólogo residente.

#### Artículo 13. Responsabilidad en la ejecución

En las intervenciones arqueológicas, la responsabilidad administrativa es solidaria, comprendiendo a los titulares de las autorizaciones, los ejecutores de obra, los directores, así como a los arqueólogos residentes, en tanto corresponda.

#### Artículo 14. Arqueólogo residente

14.1 El arqueólogo residente es el profesional debidamente colegiado y habilitado que ejecuta el plan de trabajo de una intervención arqueológica, siempre bajo la dirección y supervisión del director de dicha intervención. Su participación es opcional.

14.2 Para participar en la ejecución de cualquier modalidad de intervención arqueológica bajo la condición de arqueólogo residente, se requiere el consentimiento expreso de dicho profesional y no estar incurso en ninguno de los supuestos del artículo 5.

#### Artículo 15. Informe de resultados de las intervenciones arqueológicas

15.1 Es el documento mediante el cual se presenta toda la información registrada durante la ejecución de una intervención arqueológica, a fin de verificar el cumplimiento de los fines y objetivos.

15.2 El informe de resultados de la intervención arqueológica es elaborado por el director y es presentado por el titular y el director en el plazo establecido en la resolución de autorización.

15.3 El informe de resultados es presentado a través de la plataforma de los servicios en línea del Ministerio de Cultura o en formato físico con versión digital (CD o DVD), y es revisado para su conformidad por la Dirección de Calificación de Intervenciones Arqueológicas, la Dirección de Certificaciones, o las Direcciones Desconcentradas de Cultura, según el ámbito de sus competencias.

15.4 Solo en el caso de los PRIA se debe elaborar un informe de resultados parcial anual, y un informe de resultados al término del programa.

15.5 Si el informe de resultados es observado se pone en conocimiento del solicitante, otorgándole un plazo de diez días hábiles a partir del día hábil siguiente de la recepción de la notificación para subsanar las observaciones, dicho plazo puede ser prorrogado por única vez por el término de diez días hábiles adicionales, siempre y cuando se solicite antes de su vencimiento. Si las observaciones persisten, se mantiene la facultad de la administración de requerir única y exclusivamente, la subsanación de las observaciones, en un plazo adicional de diez días hábiles, bajo apercibimiento de denegar la solicitud de autorización del proyecto de intervención arqueológica y/o certificación. En ningún caso se puede realizar nuevas observaciones.

15.6 La unidad orgánica o dependencia competente emite el acto administrativo de conformidad o no conformidad del informe de resultados de la intervención arqueológica en un plazo máximo de treinta días hábiles.

15.7 De no haber obtenido la conformidad, el administrado puede volver a presentar su informe de resultados a través de la plataforma de los servicios en línea del Ministerio de Cultura o en formato físico con versión digital (CD o DVD), para ser revisado nuevamente.

#### Artículo 16. Compromiso de publicación

16.1 El titular y el director tienen el compromiso de publicar los resultados e interpretaciones a partir de los datos recuperados en el marco de las intervenciones autorizadas para PRIA, PIA, y PRA.

16.2 Los resultados de un PRIA deben ser presentados a manera de publicación académica tipo libro en un plazo no mayor a dos años luego de finalizada la vigencia de la intervención.

16.3 Los resultados de un PRA deben ser presentados a manera de publicación académica tipo libro en un plazo no mayor a un año luego de finalizada la vigencia de la intervención.

16.4 Los resultados de un PIA deben ser presentados a manera de artículos académicos y/o libro en un plazo no mayor a un año luego de finalizada la vigencia de la intervención.

16.5 Las publicaciones, ya sean libros, artículos,

o cualquier otro medio impreso o digital, deben ser entregadas al Ministerio de Cultura.

### CAPÍTULO II

DE LAS INTERVENCIONES ARQUEOLÓGICAS

#### Artículo 17. Autorización para la ejecución de un Programa de Investigación Arqueológica – PRIA

17.1 Las autorizaciones para un PRIA tienen una duración mínima de dos años y máxima de cinco años calendario.

17.2 El PRIA debe demostrar objetivos a largo plazo en uno o más bienes inmuebles prehispánicos, o en una región, y un diseño de investigación interdisciplinario, y una estrategia de gestión participativa hacia las comunidades aledañas, de corresponder.

17.3 En caso de que sea parte de un proyecto de inversión, el PRIA debe considerar un componente de conservación preventiva y acondicionamiento cultural de la arquitectura expuesta.

17.4 La solicitud de autorización para un PRIA debe presentarse en la plataforma de los servicios en línea del Ministerio de Cultura, o por mesa de partes en versión impresa y digital (CD o DVD); de acuerdo a los requisitos que se mencionan en los numerales 17.5, 17.6 y 17.7.

17.5 El PRIA con componente de investigación.

La solicitud de autorización de un PRIA con componente de investigación debe presentar los siguientes requisitos:

1. Solicitud presentada mediante formulario o documento que contenga la misma información, en el que se detalla lo siguiente:

a)

Datos generales del solicitante (Nombres y apellidos completos, domicilio y número de Documento Nacional de Identidad o carné de extranjería. En el caso de personas jurídicas, dicha solicitud debe estar suscrita por su representante legal, indicando el número de RUC y el número de la partida registral).

b)

Declaración jurada suscrita por el director del proyecto, indicando número de colegiatura, de habilitación, y compromiso de no afectación al patrimonio cultural, de publicación, y de financiamiento, de ser el caso.

c)

Declaración jurada suscrita por el titular del proyecto, indicando el compromiso de financiamiento, de no afectación al patrimonio cultural, y de publicación.

d)

Número de documento que emite la conformidad técnica del sector en caso la intervención provenga de un proyecto de inversión (para los PRIA con componente de puesta en valor).

e) Número de constancia y fecha de pago.

2. Información técnica mediante formulario o documento suscrito por el director propuesto que contenga:

a)

Descripción del programa (ubicación, antecedentes y problemática).

b)

Hipótesis y preguntas de la investigación interdisciplinaria.

c)

Objetivo general y objetivos específicos de la investigación interdisciplinaria.

d)

Diseño metodológico de la investigación interdisciplinaria.

e)

Plan multianual de investigaciones interdisciplinarias y cronograma.

f)

Metodología y técnicas interdisciplinarias a emplearse durante los trabajos de campo y gabinete.

g) Personal del programa y responsabilidades.

h)

Especialistas interdisciplinarios participantes y su función dentro del diseño de investigación.

i)

Presupuesto general (monto económico dispuesto para la intervención arqueológica).

j) Plan de publicación científica de los resultados.

k)

Lista de los tres últimos PIA dirigidos y lista de las publicaciones de libros y/o artículos científicos en revistas indexadas, que acredite la experiencia en investigación del director propuesto.

3. Planos perimétrico y de ubicación del área de la intervención arqueológica, presentados en formato dwg, correctamente georreferenciados en coordenadas UTM, Datum WGS 84, conteniendo la siguiente información: escalas numérica y gráfica, las cuales deben guardar relación con el grillado, membrete, cuadro de datos técnicos, ya sea en área o longitud (con vértice, lado

o progresiva, distancia, coordenadas este y norte, área, perímetro y longitud), suscritos por el profesional competente, en versión impresa y digital.

4. Copia simple del documento señalando la fuente de financiamiento y monto total asignado.

17.6 El PRIA con componente de conservación.

La solicitud de autorización de un PRIA con componente de conservación debe adjuntar los siguientes requisitos adicionales:

1. Información técnica que contenga:

a)

Diagnóstico del área a intervenir (identificación de tipos de deterioro y factores que lo originan, sustentado con procedimientos de campo y/o análisis de laboratorio).

b)

Descripción de la intervención de conservación, precisando: área y/o elementos arquitectónicos a intervenir, materiales e insumos, técnicas y/o procedimientos a realizar, sistema de registro.

c)

Especialistas interdisciplinarios participantes y su función específica en los trabajos de conservación.

2. Ficha de conservación.

3. Plano de ubicación del área y/o elementos arquitectónicos a intervenir, presentado en formato .dwg, correctamente georreferenciado en coordenadas UTM, Datum WGS 84, conteniendo la siguiente información: escalas numérica y gráfica, las cuales deben guardar relación con el grillado, membrete, cuadro de datos técnicos, ya sea en área o longitud (con vértice, lado

o progresiva, distancia, coordenadas este y norte, área, perímetro y longitud), suscrito por el profesional competente, en versión imprey digital.

4. Copia simple del Curriculum vitae que acredite estudios y/o experiencia del conservador en intervenciones en patrimonio arqueológico inmueble.

17.7 El PRIA con componente de puesta en valor.

La solicitud de autorización de un PRIA con componente de puesta en valor debe adjuntar los siguientes requisitos adicionales:

1.

Memoria descriptiva de la propuesta de puesta en valor (circuito de visitas, señalética, miradores, centro de interpretación).

2.

Plano de ubicación de la propuesta de puesta en valor (circuito de visitas, señalética, miradores, centro de interpretación), presentado en formato .dwg, correctamente georreferenciado en coordenadas UTM, Datum WGS 84, conteniendo la siguiente información: escalas numérica y gráfica, las cuales deben guardar relación con el grillado, membrete, cuadro de datos técnicos, ya sea en área o longitud (con vértice, lado o progresiva, distancia, coordenadas este y norte, área, perímetro y longitud),

suscrito por el profesional competente, en versión impresa y digital.

17.8 La Dirección de Calificación de Intervenciones Arqueológicas o la autoridad delegada para dicho efecto otorga la autorización para un PRIA, en el plazo de treinta días hábiles contados desde el primer día hábil posterior a la presentación de la solicitud, y se sujeta a las normas del silencio administrativo negativo.

#### Artículo 18. Informe de resultados

18.1 El informe de resultados parcial de un PRIA debe ser presentado por el titular y el director de la autorización mediante la plataforma de los servicios en línea del Ministerio de Cultura, o en formato físico con versión digital (CD o DVD), de acuerdo al formulario o documento establecido, en un plazo máximo de seis meses de concluido cada año de intervención, sin perjuicio de su propiedad intelectual. Dicho formulario o documento debe contener la siguiente información:

a)

Metodología aplicada en campo y gabinete.

b)

Resultados de la investigación.

c)

Resultados de los trabajos del componente de conservación, donde se precisen los elementos arquitectónicos intervenidos, las técnicas y materiales empleados, indicando su ubicación en un plano, de corresponder.

d) Inventario de bienes culturales inmuebles y muebles.

e)

Propuesta de delimitación del bien inmueble prehispánico y entrega del expediente técnico, de ser el caso.

f)

Manejo y depósito actual de los materiales recuperados en el campo.

g) Bibliografía.

h)

Planos perimétrico y de ubicación del área de la intervención arqueológica, presentados en formato .dwg, correctamente georreferenciados en coordenadas UTM, Datum WGS 84, conteniendo la siguiente información: escalas numérica y gráfica, las cuales deben guardar relación con el grillado, membrete, cuadro de datos técnicos, ya sea en área o longitud (con vértice, lado o progresiva, distancia, coordenadas este y norte, área, perímetro, y longitud), suscritos por el profesional competente, en versión impresa y digital.

18.2 El informe de resultados final de un PRIA debe ser presentado por el titular y el director de la autorización mediante la plataforma de los servicios en línea del Ministerio de Cultura, o en formato físico con versión digital (CD o DVD), de acuerdo al formulario o documento establecido, en un plazo máximo de seis meses de concluida la intervención, sin perjuicio de su propiedad intelectual. Dicho formulario o documento debe contener la siguiente información:

a) Metodología aplicada en campo y gabinete.

b)

Presentación de todos los resultados de los trabajos de campo, gabinete, y conservación.

c)

Análisis, síntesis y discusión de los resultados, contrastando evidencias e hipótesis.

d)

Conclusiones .nales.

e)

Recomendaciones para futuras investigaciones.

f)

Plan de manejo del bien inmueble prehispánico.

g)

Inventario de bienes culturales inmuebles y muebles.

h)

Propuesta de delimitación del bien inmueble prehispánico y entrega del expediente técnico, de ser el caso.

i)

Manejo y depósito actual de los materiales recuperados en el campo.

j)

Plan de difusión de la investigación que contenga las publicaciones científicas, presentaciones en eventos académicos, presencia en los medios de comunicación, divulgación a la comunidad, entre otros, realizado o por realizar.

k) Bibliografía.

l) Con relación a cada elemento arquitectónico intervenido se debe presentar la secuencia indicada a continuación:

1.

Ficha de arquitectura.

2.

Ficha de conservación.

3.

Registro fotográfico de antes y después de la intervención.

4.

Registro gráfico (elevaciones y cortes) de antes y después de la intervención.

5.

Resultado de los análisis físico-químicos de los elementos arquitectónicos, si fuera el caso.

m)

Planos perimétrico y de ubicación del área de la intervención arqueológica, presentados en formato .dwg, correctamente georreferenciados en coordenadas UTM, Datum WGS 84, conteniendo la siguiente información: escalas numérica y gráfica, las cuales deben guardar relación con el grillado, membrete, cuadro de datos técnicos, ya sea en área o longitud (con vértice, lado o progresiva, distancia, coordenadas este y norte, área, perímetro, y longitud), suscritos por el profesional competente, en versión impresa y digital.

n)

Número de acta de entrega de materiales al Ministerio de Cultura.

18.3 El acto administrativo que comunica la conformidad del informe de resultados parcial o final correspondiente a un PRIA es emitido por la Dirección de Calificación de Intervenciones Arqueológicas; además orienta al administrado sobre el procedimiento a seguir.

#### Artículo 19. Autorización para la ejecución de un Proyecto de Investigación Arqueológica – PIA

19.1 La autorización para la ejecución de un PIA tiene una duración máxima de un año.

19.2 En caso de que sea parte de un proyecto de inversión, el PIA debe considerar un componente de conservación preventiva y acondicionamiento cultural de la arquitectura expuesta.

19.3 La solicitud de autorización para la ejecución de un PIA debe presentarse en la plataforma de los servicios en línea del Ministerio de Cultura, o por mesa de partes en versión impresa y digital (CD o DVD); de acuerdo a los requisitos que se mencionan en los numerales 19.4, 19.5 y 19.6.

19.4 La solicitud de PIA con componente de investigación.

La solicitud de autorización de un PIA con componente de investigación debe presentar los siguientes requisitos:

1. Solicitud presentada mediante formulario o documento que contenga la misma información, en el que se detalla lo siguiente:

a)

Datos generales del solicitante (Nombres y apellidos completos, domicilio y número de Documento Nacional de Identidad o carné de extranjería. En el caso de personas jurídicas, dicha solicitud debe estar suscrita por su representante legal, indicando el número de RUC y el número de la partida registral).

b)

Declaración jurada suscrita por el director del proyecto, indicando número de colegiatura, de habilitación, y compromiso de financiamiento, de no afectación al patrimonio cultural, y de publicación.

c)

Número de documento que emite la conformidad técnica del sector en caso la intervención provenga de un proyecto de inversión (para los PIA con componente de puesta en valor).

d) Número de constancia y fecha de pago.

2. Información técnica mediante formulario o documento suscrito por el director propuesto que contenga:

a)

Descripción del proyecto (ubicación, antecedentes y problemática).

b)

Hipótesis y preguntas de investigación.

c)

Objetivo general y objetivos específicos.

d)

Plan de actividades y cronograma.

e)

Metodología y técnicas a emplearse durante los trabajos de campo y gabinete.

f) Personal del proyecto y responsabilidades.

g)

Presupuesto general (monto económico dispuesto para la intervención arqueológica).

3.

Planos perimétrico y de ubicación del área de la intervención arqueológica, presentados en formato .dwg, correctamente georreferenciados en coordenadas UTM, Datum WGS 84, conteniendo la siguiente información: escalas numérica y gráfica, las cuales deben guardar relación con el grillado, membrete, cuadro de datos técnicos, ya sea en área o longitud (con vértice, lado o progresiva, distancia, coordenadas este y norte, área, perímetro, y longitud), suscritos por el profesional competente, en versión impresa y digital.

4.

Copia simple del documento señalando la fuente de financiamiento y monto total asignado.

19.5 El PIA con componente de conservación.

La solicitud de autorización de un PIA con componente de conservación debe adjuntar los siguientes requisitos adicionales:

1. Información técnica que contenga:

a)

Diagnóstico del área a intervenir (identificación de tipos de deterioro y factores que lo originan, sustentado con procedimientos de campo y/o análisis de laboratorio).

b)

Descripción de la intervención de conservación, precisando: área y/o elementos arquitectónicos a intervenir, materiales e insumos, técnicas y/o procedimientos a realizar, sistema de registro.

2. Ficha de conservación.

3. Plano de ubicación del área y/o elementos arquitectónicos a intervenir presentado en formato .dwg, correctamente georreferenciado en coordenadas UTM, Datum WGS 84, conteniendo la siguiente información: escalas numérica y gráfica, las cuales deben guardar relación con el grillado, membrete, cuadro de datos técnicos, ya sea en área o longitud (con vértice, lado

o progresiva, distancia, coordenadas este y norte, área, perímetro, y longitud), suscrito por el profesional competente, en versión imprey digital.

4. Copia simple del Curriculum vitae del conservador, donde acredite estudios y/o experiencia de intervención en patrimonio arqueológico inmueble.

19.6 El PIA con componente de puesta en valor.

La solicitud de autorización de un PIA con componente de puesta en valor debe adjuntar los siguientes requisitos adicionales:

1.

Memoria descriptiva de la propuesta de puesta en valor (circuito de visitas, señalética, miradores, centro de interpretación).

2.

Plano de ubicación de la propuesta de puesta en valor (circuito de visitas, señalética, miradores, centro de interpretación), presentado en formato .dwg, correctamente georreferenciado en coordenadas UTM, Datum WGS 84, conteniendo la siguiente información: escalas numérica y gráfica, las cuales deben guardar relación con el grillado, membrete, cuadro de datos técnicos, ya sea en área o longitud (con vértice, lado o progresiva, distancia, coordenadas este y norte, área, perímetro, y longitud), suscrito por el profesional competente, en versión impresa y digital.

19.7 La Dirección de Calificación de Intervenciones Arqueológicas o la autoridad delegada para dicho efecto,

otorga la autorización para un PIA, en el plazo de treinta días hábiles contados desde el primer día hábil posterior a la presentación de la solicitud, y se sujeta a las normas del silencio administrativo negativo.

#### Artículo 20. Informe de resultados

20.1 El informe de resultados de un PIA debe ser presentado por el titular y el director de la autorización mediante la plataforma de los servicios en línea del Ministerio de Cultura, o en formato físico con versión digital (CD o DVD), de acuerdo al formulario o documento establecido, en un plazo máximo de seis meses de concluida la intervención, sin perjuicio de su propiedad intelectual. Dicho formulario o documento debe contener la siguiente información:

a)

Metodología aplicada en campo y gabinete.

b)

Resultados de la investigación y conservación.

c)

Inventario de bienes culturales inmuebles y muebles.

d)

Propuesta de delimitación del bien inmueble prehispánico y entrega del expediente técnico, de ser el caso.

e)

Manejo y depósito actual de los materiales recuperados en el campo.

f)

Plan de difusión de la investigación que contenga las publicaciones científicas, presentaciones en eventos académicos, presencia en los medios de comunicación y divulgación a la comunidad.

g) Bibliografía.

h)

Fichas de conservación, registro gráfico y fotográfico del proceso de conservación y resultado de los análisis físico-químicos de los elementos arquitectónicos, en el caso que el proyecto cuente con un componente de conservación y puesta en valor.

i)

Planos perimétricos y de ubicación presentados en formato .dwg, correctamente georreferenciados en coordenadas UTM, Datum WGS 84, conteniendo la siguiente información: escalas numérica y gráfica, las cuales deben guardar relación con el grillado, membrete, cuadro de datos técnicos, ya sea en área o longitud (con vértice, lado o progresiva, distancia, coordenadas este y norte, área, perímetro, y longitud), suscritos por el profesional competente, en versión impresa y digital.

j)

Número de acta de entrega de materiales al Ministerio de Cultura.

20.2 El acto administrativo que comunica la conformidad al informe de resultados correspondiente a un PIA es emitido por la Dirección de Calificación de Intervenciones Arqueológicas; además orienta al administrado sobre el procedimiento a seguir.

#### Artículo 21. Autorización para la ejecución de un Proyecto Arqueológico de Emergencia – PAE

21.1 La autorización para la ejecución de un PAE tiene una duración máxima de ciento ochenta días calendario. Estas autorizaciones no pueden ser ampliadas.

21.2 Las tareas a realizar comprenden trabajos de conservación preventiva, conservación, consolidación, y estabilización de estructuras. Asimismo, se considera la ejecución de excavaciones restringidas solo en función de las tareas antes mencionadas.

21.3 Para solicitar la autorización de un PAE se requiere previamente la inspección ocular del Ministerio de Cultura.

21.4 Finalizada la inspección ocular, se levanta in situ un acta que debe ser suscrita por el inspector y el profesional en arqueología que solicita el PAE. En el acta el inspector emite opinión sobre la conformidad o no conformidad de la solicitud. De contar con opinión favorable, el solicitante procede a solicitar la autorización para el PAE.

21.5 La solicitud de autorización para un PAE debe presentarse en la plataforma de los servicios en línea del Ministerio de Cultura, o por mesa de partes en versión impresa y digital (CD o DVD); de acuerdo a los siguientes requisitos:

1. Solicitud presentada mediante formulario o documento que contenga la misma información, en el que se detalla lo siguiente:

a)

Datos generales del solicitante (Nombres y apellidos completos, domicilio y número de Documento Nacional de Identidad o carné de extranjería. En el caso de personas jurídicas, dicha solicitud debe estar suscrita por su representante legal, indicando el número de RUC y el número de la partida registral).

b)

Declaración jurada suscrita por el director del proyecto, indicando número de colegiatura, de habilitación, y compromiso de no afectación al patrimonio cultural.

c)

Declaración jurada suscrita por el titular del proyecto, indicando el compromiso de financiamiento, y de no afectación al patrimonio cultural.

d) Número de constancia y fecha de pago.

2. Información técnica mediante formulario o documento suscrito por el director propuesto que contenga:

a)

Ubicación y descripción del área a intervenir.

b)

Justificación del proyecto.

c)

Diagnóstico general de conservación.

d)

Plan de conservación, protección y cronograma de trabajo, adecuado al plazo en el que se ejecutará la intervención arqueológica.

e)

Metodología y técnicas durante los trabajos de campo y conservación.

f)

Metodología y técnicas durante los trabajos de gabinete, de ser el caso.

g)

Personal del proyecto y responsabilidades.

h)

Recursos materiales y económicos.

3. Plano de ubicación del área y/o elementos arquitectónicos a intervenir presentado en formato .dwg, correctamente georreferenciado en coordenadas UTM, Datum WGS 84, conteniendo la siguiente información: escalas numérica y gráfica, las cuales deben guardar relación con el grillado, membrete, cuadro de datos técnicos, ya sea en área o longitud (con vértice, lado

o progresiva, distancia, coordenadas este y norte, área, perímetro, y longitud), suscrito por el profesional competente, en versión impresa y digital.

21.6 La Dirección de Calificación de Intervenciones Arqueológicas o la autoridad delegada para dicho efecto otorga la autorización para un PAE, en el plazo de diez días hábiles contados desde el primer día hábil posterior a la presentación de la solicitud, y se sujeta a las normas del silencio administrativo negativo.

#### Artículo 22. Informe de resultados

22.1 El informe de resultados de un PAE debe ser presentado por el titular y el director de la autorización mediante la plataforma de los servicios en línea del Ministerio de Cultura, o en formato físico con versión digital (CD o DVD), de acuerdo al formulario o documento establecido, en un plazo máximo de treinta días, hábiles, de concluida la intervención, sin perjuicio de su propiedad intelectual. Dicho formulario o documento debe contener la siguiente información:

a)

Resultados del PAE, desarrollando la conservación, protección y mitigación.

b)

Metodología aplicada en campo y gabinete.

c)

Conclusiones y recomendaciones.

d)

Inventario de bienes muebles e inmuebles, de ser el caso.

e)

Manejo y depósito actual de los materiales recuperados en el campo.

f) Bibliografía.

g)

Fichas de conservación, registro gráfico y fotográfico del proceso.

h)

Planos presentados en formato .dwg, correctamente georreferenciados en coordenadas UTM, Datum WGS 84, conteniendo la siguiente información: escalas numérica y gráfica, las cuales deben guardar relación con el grillado, membrete, cuadro de datos técnicos, ya sea en área o longitud (con vértice, lado o progresiva, distancia, coordenadas este y norte, área, perímetro, y longitud), suscritos por el profesional competente, en versión impresa y digital.

i)

Número de acta de entrega de materiales al Ministerio de Cultura.

22.1 El acto administrativo que comunica la conformidad al informe final de resultados correspondiente a un PAE es emitido por la Dirección de Calificación de Intervenciones Arqueológicas; además, orienta al administrado sobre el procedimiento a seguir.

#### Artículo 23. Autorización para la ejecución de un Proyecto de Evaluación Arqueológica – PEA

23.1 El PEA puede ser tramitado durante la fase de diseño, formulación y/o evaluación del proyecto según el sistema de inversiones Invierte.pe o el que haga sus veces.

23.2 Cuando un PEA determina mediante excavaciones la existencia de elementos arqueológicos aislados, éstos pueden ser materia de un PRA, no siendo necesario el sustento técnico de ingeniería explicando el carácter ineludible de la obra, ni la declaratoria de necesidad y utilidad pública.

23.3 Cuando se determina mediante excavaciones, que no se trata de un elemento arqueológico aislado sino de un bien inmueble prehispánico, de acuerdo con la definición del artículo VI del Título Preliminar del presente reglamento, se debe efectuar el registro, la excavación para delimitar, la elaboración de los expedientes técnicos de delimitación, y su señalización física.

23.4 No se autoriza PEA en:

1.

El área delimitada de un bien inmueble prehispánico aprobada mediante acto administrativo emitido por la autoridad competente.

2.

En bienes inmuebles prehispánicos de alto potencial arqueológico y sitios inscritos en la Lista del Patrimonio Mundial de la Organización de las Naciones Unidas para la Educación, la Ciencia y la Cultura - UNESCO.

3. En áreas arqueológicas ocupadas de manera ilegal

o

informal que pretendan obtener certificado de posesión

o

## título de propiedad y gestionar servicios públicos y/o habilitación urbana, excepto que una norma jurídica de igual o mayor jerarquía establezca lo contrario.

23.5 Excepcionalmente, se podrá autorizar PEA en los siguientes casos:

1.

En un bien inmueble prehispánico con plano de delimitación aprobado que, en cumplimiento de los parámetros técnicos de delimitación, requieran actualización catastral, previa opinión favorable de la Dirección de Catastro y Saneamiento Físico Legal y/o la que haga sus veces en las Direcciones Desconcentradas de Cultura, según el ámbito de sus competencias.

2.

En un bien inmueble prehispánico con plano de delimitación a nivel de propuesta y en proceso de aprobación, a cargo de un administrado que acredite el legítimo interés sobre el área en la cual se ha realizado la delimitación.

3.

Cuando la categorización de bienes inmuebles prehispánicos del Ministerio de Cultura así lo permita, previa presentación del sustento técnico de ingeniería que especi.que el carácter ineludible de la obra, previa opinión favorable de la Dirección de Gestión de Monumentos o la que haga sus veces en las Direcciones Desconcentradas de Cultura, según el ámbito de sus competencias.

4.

Cuando sea necesario para la gestión, protección y/o promoción del bien inmueble prehispánico, previa opinión favorable de la Dirección de Gestión de Monumentos o la que haga sus veces en las Direcciones Desconcentradas de Cultura, según el ámbito de sus competencias.

5.

Al interior de reservas y parques arqueológicos cuando su ejecución no comprometa a bienes inmuebles prehispánicos, previa opinión favorable de la Dirección de Gestión de Monumentos y/o la que haga sus veces en las Direcciones Desconcentradas de Cultura según el ámbito de sus competencias.

6.

En bienes inmuebles prehispánicos ubicados al interior de reservas y parques arqueológicos, previa opinión favorable de la Dirección de Gestión de Monumentos y/o de la que haga sus veces en las Direcciones Desconcentradas de Cultura, según el ámbito de sus competencias.

23.6 La autorización para la ejecución de un PEA en el ámbito de bienes culturales inmuebles del periodo posterior al prehispánico, no implica la autorización de obra pública o privada, o cualquier intervención civil en dichos bienes culturales.

23.7 Los PEA se tramitan en cualquiera de los siguientes supuestos:

1.

Para áreas mayores a 30 ha (300,000 m2) o distancias mayores a 20 km (20,000 m).

2.

Cuando el acto administrativo con el que se resuelve la solicitud de un CIRAS así lo recomienda.

3. A solicitud del administrado.

23.8 La solicitud de autorización para la ejecución de un PEA debe presentarse en la plataforma de los servicios en línea del Ministerio de Cultura, o por mesa de partes en versión impresa y digital (CD o DVD); de acuerdo con los siguientes requisitos:

1. Solicitud presentada mediante formulario o documento que contenga la misma información, en el que se detalla lo siguiente:

a)

Datos generales del solicitante (Nombres y apellidos completos, domicilio y número de Documento Nacional de Identidad o carné de extranjería. En el caso de personas jurídicas, dicha solicitud debe estar suscrita por su representante legal, indicando el número de RUC y el número de la partida registral).

b)

Declaración jurada suscrita por el director del proyecto, indicando número de colegiatura, de habilitación, y compromiso de no afectación al patrimonio cultural.

c)

Declaración jurada suscrita por el titular del proyecto, indicando el compromiso de financiamiento, y de no afectación al patrimonio cultural.

d)

Número de partida registral, o número de resolución que otorga la adjudicación o concesión, o código único de inversiones (o código SNIP) que acredite la titularidad de la viabilidad del proyecto de inversión. De no encontrarse registrado el derecho de propiedad ante la SUNARP, se debe acreditar la condición de propietario en forma documental, presentando copia simple de la escritura pública, o minuta, o contrato de compra venta.

e) Número de constancia y fecha de pago.

2. Información técnica mediante formulario o documento suscrito por el director propuesto que contenga:

a)

Nombre del PEA.

b)

Ubicación del proyecto.

c)

Extensión del área del proyecto.

d)

Cuadro de datos técnicos del área de intervención del proyecto.

e) Metodología de campo y gabinete.

f)

Descripción técnica resumida del proyecto materia del PEA.

g) Personal del proyecto y cronograma.

h) Presupuesto general (monto económico dispuesto para la intervención arqueológica).

3. Plano perimétrico del área de la intervención arqueológica, presentado en formato .dwg, correctamente georreferenciado en coordenadas UTM, Datum WGS 84, conteniendo la siguiente información: escalas numérica y gráfica, las cuales deben guardar relación con el grillado, membrete, cuadro de datos técnicos, ya sea en área o longitud (con vértice, lado o progresiva, distancia, coordenadas este y norte, área, perímetro, longitud, y servidumbre), suscrito por el profesional competente, en versión impresa y digital, de acuerdo a los modelos aprobados, según correspondan.

23.9 La Dirección de Calificación de Intervenciones Arqueológicas o la autoridad delegada para dicho efecto otorga la autorización para la ejecución de un PEA, en el plazo de treinta días hábiles contados desde el primer día hábil posterior a la presentación de la solicitud, y se sujeta a las normas del silencio administrativo negativo.

#### Artículo 24. Informe de resultados

24.1 El informe de resultados de un PEA debe ser presentado por el titular y el director de la autorización mediante la plataforma de los servicios en línea del Ministerio de Cultura, o en formato físico con versión digital (CD o DVD), de acuerdo al formulario o documento establecido, en un plazo máximo de seis meses de concluida la intervención, sin perjuicio de su propiedad intelectual. Dicho formulario o documento debe contener la siguiente información:

a)

Evaluación de los impactos de la obra sobre los bienes inmuebles prehispánicos y medidas de mitigación.

b)

Metodología aplicada en campo y gabinete.

c)

Resultados de la evaluación arqueológica.

d)

Propuesta del grado de potencialidad de los bienes inmuebles prehispánicos, de ser el caso.

e)

Inventario de bienes muebles e inmuebles, de corresponder.

f)

Propuesta de delimitación del bien inmueble prehispánico y entrega del expediente técnico, de ser el caso, adjuntando el registro fotográfico de la señalización y demarcación física realizada.

g)

Presentación del registro arqueológico completo que incluye fichas de campo, copias de dibujos y fotografías.

h) Bibliografía.

i)

Planos presentados en formato .dwg, correctamente georreferenciados en coordenadas UTM, Datum WGS 84, conteniendo la siguiente información: escalas numérica y gráfica, las cuales deben guardar relación con el grillado, membrete, cuadro de datos técnicos, ya sea en área o longitud (con vértice, lado o progresiva, distancia, coordenadas este y norte, área, perímetro, longitud, y servidumbre), suscritos por el profesional competente, en versión impresa y digital, de acuerdo a los modelos aprobados, según correspondan.

j)

Número de acta de entrega de materiales al Ministerio de Cultura.

24.2 El acto administrativo que comunica la conformidad al informe de resultados correspondiente a un PEA es emitido por la Dirección de Calificación de Intervenciones Arqueológicas; además, orienta al administrado sobre el procedimiento a seguir.

#### Artículo 25. Autorización para la ejecución de un Proyecto de Rescate Arqueológico – PRA

25.1 De ser necesario realizar un rescate arqueológico en un bien inmueble prehispánico, se debe determinar de manera previa el potencial arqueológico. Para estos casos será necesario contar con el sustento técnico de ingeniería del carácter ineludible de la obra y, cuando corresponda, la declaratoria de necesidad y utilidad pública.

25.2 Para la ejecución de los PRA, el carácter ineludible y la declaración de necesidad y utilidad pública no son las únicas condiciones para su autorización. Conforme a las competencias del Ministerio de Cultura establecidas en el numeral 3 del artículo II del presente reglamento, la autorización de un PRA también está condicionada a la categorización del bien inmueble prehispánico materia de la solicitud.

25.3 En el caso de los PMAR, ante el hallazgo de un bien inmueble prehispánico detectado durante los trabajos de remoción de suelos, los PRA pueden ser solicitados durante su vigencia o posterior a ésta, y debe ser gestionado durante la fase de ejecución de la inversión.

25.4 Todo PRA, de manera indefectible, considera la aplicación de medidas de protección y de mitigación de carácter compensatorio, acorde al nivel y/o grado del impacto ocasionado.

25.5 Los PRA se tramitan:

1.

Luego de la ejecución de un PEA, de ser el caso.

2.

Durante la ejecución de un PMAR, de ser el caso.

25.6 En el caso de los PRA que provienen de PEA, deben ser solicitados luego de la conformidad del informe de resultados del PEA, y deben ser ejecutados antes del inicio de la obra.

25.7 La solicitud de autorización para un PRA debe presentarse en la plataforma de los servicios en línea del Ministerio de Cultura, o por mesa de partes en versión impresa y digital (CD o DVD); de acuerdo con los requisitos que se mencionan en los numerales a continuación:

1. Solicitud presentada mediante formulario o documento que contenga la misma información, en el que se detalla lo siguiente:

a)

Datos generales del solicitante (Nombres y apellidos completos, domicilio y número de Documento Nacional de Identidad o carné de extranjería. En el caso de personas jurídicas, dicha solicitud debe estar suscrita por su representante legal, indicando el número de RUC y el número de la partida registral).

b)

Declaración jurada suscrita por el director del proyecto, indicando número de colegiatura, de habilitación, compromiso de no afectación al patrimonio cultural, y de publicación.

c)

Declaración jurada suscrita por el titular del proyecto, indicando el compromiso de financiamiento, de no afectación al patrimonio cultural, y de publicación.

d)

Número de partida registral, o número de resolución que otorga la adjudicación o concesión, o código único de inversiones (o código SNIP) que acredite la titularidad de la viabilidad del proyecto de inversión. De no encontrarse registrado el derecho de propiedad ante la SUNARP, se debe acreditar la condición de propietario en forma documental, presentando copia simple de la escritura pública, o minuta, o contrato de compra venta.

e) Número de constancia y fecha de pago.

2. Información técnica mediante formulario o documento suscrito por el director propuesto que contenga:

a)

Nombre del proyecto.

b)

Ubicación del proyecto.

c)

Datos técnicos del área de intervención.

d)

Número de documento normativo que declara de necesidad e interés público la obra, de corresponder.

e)

Antecedentes arqueológicos (resumen del PEA).

f)

Descripción técnica resumida materia del PRA.

g)

Metodología de campo y gabinete.

h)

Propuesta de plan de mitigación.

i)

Propuesta de plan de investigación y conservación interdisciplinaria.

j)

Propuesta de publicación y difusión de los resultados.

k)

Personal del proyecto.

l)

Lista de intervenciones en PEA y PRA que acredite la experiencia en la dirección de estas modalidades.

m) Cronograma.

n)

Presupuesto general (monto económico dispuesto para la intervención arqueológica).

3.

Documento técnico de ingeniería que sustente el carácter ineludible de la obra, avalado por el sector correspondiente, de ser el caso.

4.

Planos del área de la intervención arqueológica, presentados en formato .dwg, correctamente georreferenciados en coordenadas UTM, Datum WGS 84, conteniendo la siguiente información: escalas numérica y gráfica, las cuales deben guardar relación con el grillado, membrete, cuadro de datos técnicos, ya sea en área o longitud (con vértice, lado o progresiva, distancia, coordenadas este y norte, área, perímetro, longitud, y servidumbre), suscritos por el profesional competente, en versión impresa y digital, de acuerdo a los modelos aprobados, según correspondan.

25.8 El PRA que procede de un PMAR.

La solicitud de autorización para un PRA durante la ejecución de un PMAR debe adjuntar el siguiente requisito adicional:

1. Diagnóstico preliminar que contiene la siguiente información:

a)

Descripción detallada de las evidencias materia del rescate, incluyendo sus dimensiones, características, y componentes.

b) Registro gráfico, fotográfico y fílmico.

c)

Plano de delimitación del bien inmueble prehispánico y del área materia de rescate, presentado en formato .dwg, correctamente georreferenciado en coordenadas UTM, Datum WGS 84, conteniendo la siguiente información: escalas numérica y gráfica, las cuales deben guardar relación con el grillado, membrete, cuadro de datos técnicos, ya sea en área o longitud (con vértice, lado o progresiva, distancia, coordenadas este y norte, área, perímetro, longitud, y servidumbre), suscrito por el profesional competente, en versión impresa y digital.

d)

Número y fecha del acta de inspección que incluya la opinión del inspector con respecto a la viabilidad del rescate.

e)

Resultado de la evaluación del potencial arqueológico.

25.9 La Dirección de Calificación de Intervenciones Arqueológicas o la autoridad delegada para dicho efecto otorga la autorización para un PRA, en el plazo de treinta días hábiles contados desde el primer día hábil posterior a la presentación de la solicitud, y se sujeta a las normas del silencio administrativo negativo.

#### Artículo 26. Informe de resultados

26.1 El informe de resultados de un PRA debe ser presentado por el titular y el director de la autorización mediante la plataforma de los servicios en línea del Ministerio de Cultura, o en formato físico con versión digital (CD o DVD), de acuerdo al formulario o documento establecido, en un plazo máximo de seis meses de concluida la intervención, sin perjuicio de su propiedad intelectual. Dicho formulario o documento debe contener la siguiente información:

a) Generalidades.

b)

Metodología aplicada en campo, gabinete, y conservación de bienes muebles.

c)

Resultados del PRA.

d)

Plan de mitigación.

e)

Plan de investigación y conservación interdisciplinaria.

f) Plan de publicación y difusión de los resultados.

g)

Inventario de los remanentes inmuebles.

h)

Inventario de bienes muebles.

i)

Bibliografía.

j)

Planos presentados en formato .dwg, correctamente georreferenciados en coordenadas UTM, Datum WGS 84, conteniendo la siguiente información: escalas numérica y gráfica, las cuales deben guardar relación con el grillado, membrete, cuadro de datos técnicos, ya sea en área o longitud (con vértice, lado o progresiva, distancia, coordenadas este y norte, área, perímetro, longitud, y servidumbre), suscritos por el profesional competente, en versión impresa y digital, de acuerdo a los modelos aprobados, según correspondan.

k)

Presentación del registro arqueológico completo que incluye fichas de campo, copias de dibujos, fotografías y videos.

l)

Número de acta de entrega de materiales al Ministerio de Cultura.

26.2 El acto administrativo que comunica la conformidad al informe de resultados correspondiente a un PRA es emitido por la Dirección de Calificación de Intervenciones Arqueológicas; además, orienta al administrado sobre el procedimiento a seguir.

26.3 De ser el caso, previa conformidad al informe de resultados, el administrado puede solicitar el retiro de la condición de bien cultural.

#### Artículo 27. Autorización para la ejecución de un Plan de Monitoreo Arqueológico – PMAR

27.1 La autorización para ejecutar un PMAR debe ser obtenida de manera previa al inicio de las obras que impliquen remoción de suelos o a la ejecución de los proyectos destinados a la implementación de infraestructura relacionada a la puesta en valor del Patrimonio Cultural de la Nación.

27.2 La autorización solicitada debe corresponder a los componentes de un solo proyecto de inversión.

27.3 El director de un PMAR, en coordinación con el Ministerio de Cultura, debe adoptar e implementar las acciones necesarias en caso de encontrar hallazgos de evidencias culturales bajo superficie en el área de intervención.

27.4 Por la naturaleza y/o extensión del proyecto, que implique la ejecución simultánea de dos o más frentes de trabajo, se debe contar con la participación de más de un arqueólogo residente para garantizar el monitoreo permanente. Para tal efecto, el cronograma de ejecución de obra debe especificar las labores que impliquen la remoción de suelos, su tiempo de duración, y la distribución de los diferentes frentes de trabajo.

27.5 En la ejecución de un PMAR se debe considerar las medidas de mitigación necesarias para aquellas áreas fuera del proyecto que, por su colindancia y/o proximidad a la obra, pueden afectar el Patrimonio Cultural de la Nación.

27.6 El PMAR es de implementación obligatoria, teniendo el Ministerio de Cultura la competencia para disponer la paralización de la obra en caso de incumplimiento, así como para dictar las medidas correctivas que estime pertinentes en salvaguarda del Patrimonio Cultural de la Nación.

27.7 Cuando un PMAR se ejecute en infraestructura preexistente se verifica tal condición a través de una inspección a cargo de la Dirección de Certificaciones o la que haga sus veces en las Direcciones Desconcentradas de Cultura, según el ámbito de sus competencias.

27.8 En el caso de la ejecución de una obra que involucre un bien inmueble integrante del Patrimonio Cultural de la Nación del periodo posterior al prehispánico, se requiere la autorización de la Dirección General de Patrimonio Cultural o de las Direcciones Desconcentradas de Cultura, u opinión favorable del delegado ad hoc del Ministerio de Cultura, según corresponda.

27.9 En el caso de la ejecución de una obra que se desarrolle en un medio subacuático, se requiere de

manera previa la opinión favorable de la Dirección General de Patrimonio Cultural.

27.10 En el caso de proyectos u obras desarrolladas en medios subacuáticos, la implementación de un PMAR debe contemplar una metodología de trabajo para la zona intermareal, y otra para la zona subacuática.

27.11 Los PMAR proceden de:

1.

Un PIA cuando se necesite infraestructura para la gestión, protección, y/o promoción del bien inmueble prehispánico.

2.

Un PEA cuando el acto administrativo que da conformidad al informe de la intervención así lo indique.

3.

Un PRA.

4.

Del CIRAS.

5. De infraestructura preexistente y en medios subacuáticos hasta la línea de marea alta o zona inundable.

27.12 La solicitud de autorización para la ejecución de un PMAR debe presentarse en la plataforma de los servicios en línea del Ministerio de Cultura, o por mesa de partes en versión impresa y digital (CD o DVD); de acuerdo con los requisitos que se mencionan en los numerales 27.14, 27.16, 27.18 y 27.20.

27.13 La Dirección de Certificaciones o la Dirección Desconcentrada de Cultura otorgan la autorización de un PMAR, de acuerdo al ámbito de sus competencias.

27.14 El PMAR sin infraestructura preexistente.

La solicitud de autorización para un PMAR sin infraestructura preexistente, debe contener los siguientes requisitos:

1. Solicitud presentada mediante formulario o documento que contenga la misma información, en el que se detalla lo siguiente:

a)

Datos generales del solicitante (Nombres y apellidos completos, domicilio y número de Documento Nacional de Identidad o carné de extranjería. En el caso de personas jurídicas, dicha solicitud debe estar suscrita por su representante legal, indicando el número de RUC y el número de la partida registral).

b)

Declaración jurada suscrita por el director del proyecto, indicando número de colegiatura, de habilitación, y compromiso de no afectación al patrimonio cultural.

c)

Declaración jurada suscrita por el titular del proyecto, indicando el compromiso de financiamiento, y de no afectación al patrimonio cultural.

d) Número de constancia y fecha de pago.

2. Información técnica mediante formulario o documento suscrito por el director propuesto que contenga:

a)

Información general del proyecto (nombre, modalidad, y procedencia, tipo de obra, nivel de intervención, ubicación, generalidades y/o alcances del proyecto y, de ser el caso, actividades desarrolladas con anterioridad en el área del proyecto).

b)

Descripción técnica del PMAR (objetivos y fines, antecedentes arqueológicos e históricos de la zona del proyecto, descripción específica de la obra a ejecutar indicando la actividad de ingeniería en cuyo marco se aplicará la intervención arqueológica, metodología a aplicar en campo y gabinete, metodología para las zonas intermareal y subacuática, extensión a monitorear, personal del proyecto y cronograma).

c)

Medidas de mitigación y/o prevención propuestas al PMAR.

3. Planos perimétrico y de obras programadas del área de la intervención arqueológica, presentados en formato .dwg, correctamente georreferenciados en coordenadas UTM, Datum WGS 84, conteniendo la siguiente información: escalas numérica y gráfica, las cuales deben guardar relación con el grillado, membrete, cuadro de datos técnicos, ya sea en área y/o longitud (con vértice, lado y/o progresiva, distancia, coordenadas este y norte, área, perímetro, longitud, y servidumbre), suscritos por el profesional competente, en versión impresa y digital, de acuerdo a los modelos aprobados, según correspondan.

Los documentos técnicos especificados en los planos deben expresarse y representarse en unidades de medida de acuerdo a la naturaleza de la obra. De preferencia, para casos como la implementación de líneas de transmisión, carreteras, tuberías de agua y desagüe,gasoductos,canales, y obras semejantes, debe expresarse longitudinalmente en metros (m) o kilómetros (km), indicando su respectiva servidumbre en metros. Tratándose de predios, áreas de concesión minera, represas, y otros que lo requieran, las áreas se expresarán en metros cuadrados (m²) o hectáreas (ha), con su perímetro correspondiente en metros.

27.15 El plazo máximo para otorgar la autorización para la ejecución de un PMAR sin infraestructura preexistente no debe exceder los diez días hábiles, contados desde el primer día hábil posterior a la presentación de la solicitud, y se sujeta a las normas del silencio administrativo negativo.

27.16 El PMAR con infraestructura preexistente.

La solicitud de autorización para un PMAR con infraestructura preexistente, además de los requisitos del PMAR sin infraestructura preexistente, debe adjuntar el siguiente requisito adicional:

1. Documentación gráfica (fotografías panorámicas y a detalle e imágenes satelitales) que permita el reconocimiento de la infraestructura preexistente.

27.17 El plazo máximo para otorgar la autorización para la ejecución de un PMAR con infraestructura preexistente no debe exceder los veinte días hábiles, contados desde el primer día hábil posterior a la presentación de la solicitud, y se sujeta a las normas del silencio administrativo negativo.

27.18 El PMAR en medio subacuático.

La solicitud de autorización para la ejecución de un PMAR en medio subacuático, además de los requisitos del PMAR con o sin infraestructura preexistente, de ser el caso, debe adjuntar los siguientes requisitos adicionales:

1.

Copia simple del informe conteniendo la identificación y verificación de anomalías del área de intervención, acompañado del análisis y diagnóstico de los estudios geofísicos e imágenes generadas por los instrumentos geofísicos o remotos.

2.

Copia simple del diagnóstico de existencia/ inexistencia de patrimonio cultural conteniendo los antecedentes arqueológicos y/o históricos, la caracterización del fondo del lecho marino del área de intervención, estudio de variabilidad de línea de litoral (en caso de involucrar la línea costera).

27.19 El plazo máximo para otorgar la autorización para la ejecución de un PMAR en medio subacuático no debe exceder los veinte días hábiles, contados desde el primer día hábil posterior a la presentación de la solicitud, y se sujeta a las normas del silencio administrativo negativo.

27.20 El PMAR en un bien inmueble integrante del Patrimonio Cultural de la Nación del periodo posterior al prehispánico.

La solicitud de autorización para la ejecución de un PMAR en un bien inmueble integrante del Patrimonio Cultural de la Nación de periodo posterior al prehispánico, además de los requisitos del PMAR con o sin infraestructura preexistente, de ser el caso, debe adjuntar los siguientes requisitos adicionales:

a) Para proyectos autorizados en el marco de la Ley Nº 29090:

1.

Copia simple de la resolución que autoriza la licencia de edificación emitida por la municipalidad correspondiente.

2.

Copia simple de los planos aprobados por la comisión técnica.

b) Para proyectos autorizados en el marco de la Ley General del Patrimonio Cultural de la Nación - Ley Nº 28296:

1. Número de resolución directoral que aprueba la ejecución de la obra por parte de la Dirección General de Patrimonio Cultural del Ministerio de Cultura o de las Direcciones Desconcentradas de Cultura, según corresponda.

27.21 El plazo máximo para otorgar la autorización para la ejecución de un PMAR de un bien inmueble integrante del Patrimonio Cultural de la Nación del periodo posterior al prehispánico no debe exceder de los veinte días hábiles, contados desde el primer día hábil posterior a la presentación de la solicitud, y se sujeta a las normas del silencio administrativo negativo.

#### Artículo 28. Acciones en caso de hallazgos

28.1 Ante el hallazgo de evidencias culturales durante la ejecución de un PMAR, se suspenden inmediatamente las obras en el área específica del hallazgo. Se procede a comunicar al Ministerio de Cultura, en un plazo no mayor del día hábil siguiente del hallazgo, a fin de que se disponga las acciones que correspondan.

28.2 Se pueden efectuar excavaciones con la finalidad de determinar la extensión del hallazgo, su potencial arqueológico, su delimitación y señalización, de acuerdo a lo establecido en el PMAR, entendiéndose que dichos trabajos no constituyen un rescate arqueológico. Se procede de la siguiente manera en función al tipo de hallazgo:

1.

Cuando se confirma que se trata de elementos arqueológicos aislados, el director o el arqueólogo residente procede a su registro, recolección y/o inventario bajo su responsabilidad. Durante las inspecciones oculares, el director da cuenta de las evidencias halladas, presentando el registro de excavación de las mismas.

2.

Cuando no se trata de un elemento arqueológico aislado, el hallazgo forma parte de los Sitios Arqueológicos, Complejos Arqueológicos, o Paisajes Arqueológicos, conforme se define en el artículo VI del Título Preliminar del presente reglamento, y se debe efectuar el registro, excavación para delimitar, y la señalización física de los bienes inmuebles prehispánicos. En caso de considerar un rescate, se debe excavar para determinar el potencial arqueológico.

28.3 En el caso de hallazgos en medios subacuáticos referidos a evidencias arqueológicas y/o históricas contextualizadas, el Ministerio de Cultura debe determinar su zona de exclusión, en coordinación con las autoridades competentes. Se considera preferible la conservación in situ y demás medidas de mitigación necesarias para evitar afectaciones durante la ejecución de las obras. Para tal efecto, se debe poner en conocimiento a la autoridad competente que autorizó el PMAR, bajo responsabilidad.

#### Artículo 29. Informe de resultados

29.1 El informe de resultados de un PMAR debe ser presentado por el titular y el director mediante la plataforma de los servicios en línea del Ministerio de Cultura, o en formato físico con versión digital (CD o DVD), en un plazo máximo de seis meses de concluida la intervención.

29.2 En el caso que un PMAR haya sido autorizado por más de un año, se debe presentar un informe de resultados parcial el cual contendrá la información indicada en los numerales 29.3 y 29.4 del presente reglamento.

29.3 El informe de resultados de un PMAR contiene la información sobre la excavación, revisión de per.les y desmontes, medidas de mitigación, intervención de hallazgos, elementos arqueológicos aislados, bienes inmuebles prehispánicos, trabajos de gabinete e inducción, de acuerdo al formulario.

29.4 Para la presentación del informe de resultados de un PMAR se adjuntan adicionalmente los siguientes documentos:

a)

Inventario de bienes muebles e inmuebles detallado, de ser el caso. En los planes que se realicen en medios subacuáticos, se debe indicar los materiales que son devueltos al medio subacuático y aquellos que son materia de trabajos de estabilización y conservación de.nitiva.

b)

Delimitación del bien o los bienes inmuebles prehispánicos, y entrega del expediente técnico, adjuntando fotografías de la señalización y demarcación física del bien o los bienes inmuebles prehispánicos registrados, de ser el caso.

c)

Fichas de inducción llenadas y firmadas por el director del plan y el ingeniero responsable de la obra, en formato digital.

d)

Fichas diarias de control del PMAR firmadas por el director en formato digital y, en caso de la presentación de hallazgos, las fichas respectivas.

e)

En caso el PMAR no haya cubierto la totalidad del área autorizada, se debe adjuntar un plano georreferenciado de acuerdo al modelo aprobado.

f)

Número de acta de entrega de materiales al Ministerio de Cultura, de corresponder.

29.5 La Dirección de Certificaciones o la Dirección Desconcentrada de Cultura, de acuerdo al ámbito de sus competencias, emite la conformidad al informe de resultados del PMAR a través del respectivo acto administrativo.

#### Artículo 30. Ampliación o renovación de la vigencia de la autorización de las intervenciones arqueológicas

30.1 La ampliación de la vigencia de la autorización es solicitada por el titular de la intervención cuando, en el plazo previsto, no haya podido cumplir sus objetivos, o cuando no haya podido ejecutar o finalizar la intervención por razones de fuerza mayor o caso fortuito.

30.2 No procede la ampliación de la vigencia de autorización para un PAE y un PRIA.

30.3 La ampliación debe ser solicitada durante la vigencia de la intervención arqueológica, ante la Dirección de Calificación de Intervenciones Arqueológicas, la Dirección de Certificaciones o las Direcciones Desconcentradas de Cultura, según el ámbito de sus competencias. Toda solicitud de ampliación de la vigencia de la autorización presentada con posterioridad a su vencimiento es improcedente.

30.4 No procede una ampliación de la autorización si el titular y/o el director estuviesen incursos en cualquiera de los supuestos establecidos en el artículo 5 del presente reglamento.

30.5 La solicitud para ampliar la vigencia de la autorización de las intervenciones arqueológicas debe presentarse en la plataforma de los servicios en línea del Ministerio de Cultura, o por mesa de partes en versión impresa y digital (CD o DVD).

La solicitud de ampliación debe adjuntar los siguientes requisitos:

1. Solicitud presentada mediante formulario o documento que contenga la misma información, en el que se detalla lo siguiente:

a)

Datos generales del solicitante (Nombres y apellidos completos, domicilio y número de Documento Nacional de Identidad o carné de extranjería. En el caso de personas jurídicas, dicha solicitud debe estar suscrita por su representante legal, indicando el número de RUC y el número de la partida registral).

b)

Número de resolución directoral que autorizó la intervención.

c) Número de constancia y fecha de pago.

2.

Copia simple del informe que sustenta la necesidad de la ampliación explicando en detalle las razones que impidieron cumplir el objetivo.

3.

Copia simple del informe del avance de los trabajos ejecutados hasta la fecha de la presentación de la solicitud.

4. Plan de trabajo y cronograma.

5. Presupuesto general (monto económico dispuesto para la intervención arqueológica).

30.6 La ampliación es concedida por el mismo plazo de la autorización previamente otorgada, y es autorizada mediante acto administrativo del órgano competente.

30.7 El plazo máximo para otorgar una ampliación de la vigencia de la autorización de las intervenciones arqueológicas es de diez días hábiles contados desde el primer día hábil posterior a la presentación de la solicitud, y se sujeta a las normas del silencio administrativo negativo.

30.8 La ampliación de la vigencia de la autorización de las intervenciones arqueológicas puede ser renovada por única vez, hasta el mismo plazo de la ampliación previamente otorgada.

30.9 La solicitud de renovación de la vigencia de la autorización de las intervenciones arqueológicas debe adjuntar los siguientes requisitos:

1. Solicitud presentada mediante formulario o documento que contenga la misma información, en el que se detalla lo siguiente:

a)

Datos generales del solicitante (Nombres y apellidos completos, domicilio y número de Documento Nacional de Identidad o carné de extranjería. En el caso de personas jurídicas, dicha solicitud debe estar suscrita por su representante legal, indicando el número de RUC y el número de la partida registral).

b)

Número de resolución directoral que autorizó la ampliación.

c)

Información detallada sobre la necesidad de la renovación.

d) Número de constancia y fecha de pago.

2.

Copia simple del informe del avance de los trabajos ejecutados hasta la fecha de la presentación de la solicitud.

3. Plan de trabajo y cronograma.

4.

Presupuesto general (monto económico dispuesto para la intervención arqueológica).

30.10 El plazo máximo para otorgar la renovación de la vigencia de la autorización de las intervenciones arqueológicas es de diez días hábiles contados desde el primer día hábil posterior a la presentación de la solicitud, y se sujeta a las normas del silencio administrativo negativo.

30.11 La renovación de la vigencia debe ser solicitada durante la vigencia de la ampliación de la autorización de la intervención arqueológica, ante la Dirección de Calificación de Intervenciones Arqueológicas, la Dirección de Certificaciones o las Direcciones Desconcentradas de Cultura, según el ámbito de sus competencias. Toda solicitud de renovación de la vigencia presentada con posterioridad a su vencimiento es improcedente.

#### Artículo 31. Inspección ocular y supervisión técnica de campo

31.1 Inspección ocular

31.1.1 La inspección ocular consiste en el seguimiento y control de las intervenciones arqueológicas las que se ejecutan de acuerdo a los términos de la resolución de autorización. Se verifica en campo los objetivos planteados; el adecuado registro de los trabajos y hallazgos; las técnicas y metodologías apropiadas para la excavación, conservación y trabajos en gabinete, indicando al director de la intervención las opiniones y recomendaciones sobre lo observado en los trabajos de campo.

31.1.2 En el acto administrativo que autoriza las intervenciones arqueológicas se establece el número y frecuencia de las inspecciones oculares, según la naturaleza y el periodo de la intervención. Para las intervenciones arqueológicas con un plazo de ejecución mayor a treinta días calendario, se debe contar con inspecciones oculares coordinadas con el Director de la intervención arqueológica.

31.1.3 Para el caso de trabajos de campo menores a treinta días calendario, se realiza como mínimo una inspección ocular coordinada con el Director de la intervención arqueológica antes de finalizar la intervención.

31.1.4 Por cada inspección ocular se debe elaborar in situ un acta de inspección que es suscrita por el inspector del Ministerio de Cultura y el director de la intervención, en la que se precisan las observaciones y recomendaciones advertidas de ser el caso, cuya ejecución de la inspección y subsanación de las observaciones deben ser verificadas por el inspector antes de concluir la fase de trabajo de campo de la intervención.

31.1.5 El acta de inspección ocular de los PIA, PRIA, PEA, PRA, PAE es remitida a la Dirección de Calificación de Intervenciones Arqueológicas, en un plazo máximo de tres días hábiles luego de suscrita. El acta de inspección ocular tiene rango de informe técnico y su elaboración es condición necesaria para la evaluación del informe de resultados.

31.1.6 A través de la inspección ocular se puede evaluar la necesidad de replantear cambios en las dimensiones de las excavaciones de los PIA y los PRIA, siempre que ello no implique modificaciones al cronograma aprobado para la intervención arqueológica ni a los objetivos de la misma.

31.1.7 Para el caso de los PRIA y PIA con componente de investigación, y PEA que hayan intervenido en un bien inmueble prehispánico, en la última inspección ocular se verifica que se cumpla con el tapado de las unidades de excavación a fin de proteger y salvaguardar el Patrimonio Cultural de la Nación.

31.1.8 Para el caso del PMAR, la inspección ocular puede realizarse mensualmente según el tipo de la obra.

31.1.9 Independientemente de las inspecciones coordinadas, el Ministerio de Cultura se reserva el derecho de realizar inspecciones de oficio cuando así lo considere conveniente.

31.2 Supervisión técnica de campo a solicitud de parte

31.2.1 En el marco de una intervención arqueológica, el Ministerio de Cultura realiza la supervisión técnica de campo a solicitud de parte, como mecanismo de orientación en la ejecución de trabajos de campo o determinación de hallazgos pertenecientes al Patrimonio Cultural de la Nación.

Las supervisiones técnicas de campo a solicitud de parte se realizan mediante servicio prestado en exclusividad, acompañando los siguientes requisitos:

1. Solicitud presentada mediante formulario o documento que contenga la misma información, en el que se detalla lo siguiente:

a)

Datos generales del solicitante (Nombres y apellidos completos, domicilio y número de Documento Nacional de Identidad o carné de extranjería. En el caso de personas jurídicas, dicha solicitud debe estar suscrita por su representante legal, indicando el número de RUC y el número de la partida registral).

b)

Número de resolución directoral que autorizó la intervención.

c) Número de constancia y fecha de pago.

La solicitud es presentada a la Dirección General de Patrimonio Arqueológico Inmueble, y debe ser atendida en un plazo no mayor de diez días hábiles contados desde el primer día hábil posterior a la presentación de la misma.

31.2.2 Luego de concluida la supervisión técnica de campo se elabora un acta la cual es entregada en el momento al solicitante.

## TÍTULO II

CERTIFICADO DE INEXISTENCIA DE RESTOS ARQUEOLÓGICOS EN SUPERFICIE - CIRAS

### CAPÍTULO I

### DISPOSICIONES GENERALES

#### Artículo 32. Definición

El Certificado de Inexistencia de Restos Arqueológicos en Superficie - CIRAS es el documento mediante el cual el Ministerio de Cultura certifica, a solicitud de parte, que en un área determinada no existen evidencias arqueológicas en superficie. El CIRAS procede de la verificación en superficie luego de una inspección ocular o de un PEA,

o de un PRA luego de la excavación total en la dimensión vertical, cuando un bien inmueble prehispánico haya sido rescatado total o parcialmente en la dimensión horizontal.

#### Artículo 33. Aspectos generales

33.1 La solicitud de CIRAS tiene dos intervalos de dimensión según la extensión y la unidad de medida del proyecto:

a) Solicitud en área: De 0 ha a 10 ha (100,000 m2). Mayor a 10 ha (mayor a 100,000 m2) hasta 30 ha

(300,000 m2).

b) Solicitud longitudinal: De 0 km a 10 km (10,000 m). Mayor a 10 km (mayor a 10,000 m) hasta 20 km

(20,000 m).

33.2 En caso el proyecto de inversión se ejecute en regiones diferentes, la solicitud del CIRAS es presentada en la instancia administrativa en cuyo ámbito de competencia se encuentre la mayor área y/o longitud solicitada. En caso se trate de áreas y/o longitudes equivalentes, la solicitud es evaluada por cualquiera de las instancias administrativas involucradas, a elección del solicitante.

33.3 Para la ejecución de obras o proyectos de inversión pública y/o privada no es exigible la obtención del CIRAS en los supuestos establecidos en el numeral 5 del artículo 27.11; sin embargo, se puede expedir CIRAS en dichos supuestos a solicitud del administrado, siempre y cuando no exista evidencia arqueológica en superficie y/o no tenga antecedentes catastrales arqueológicos registrado en el Ministerio de Cultura; además, se puede expedir CIRAS en áreas que ya cuenten con CIRAS aprobados con otro titular.

En los casos establecidos en el presente numeral, el titular del proyecto de inversión ejecuta un PMAR, según lo establecido en el numeral 27.11 del presente reglamento, siempre y cuando no exista evidencia arqueológica en superficie.

33.4. Tratándose de áreas que hayan sido objeto de un PEA, el CIRAS es expedido para las áreas sin evidencia arqueológica en superficie, cuando así lo solicite el administrado y así se indique en el acto administrativo que brinda la conformidad al informe de resultados del PEA.

33.5 En los casos de PEA ejecutados en reservas y parques arqueológicos el acto administrativo que brinda la conformidad al informe de resultados del PEA puede recomendar la ejecución de un PMAR para las áreas sin evidencia arqueológica en superficie, de ser el caso.

Consecuentemente, una vez aprobado el informe final de un PEA o PRA al interior de una Reserva Arqueológica o Parque Arqueológica, la Dirección de Catastro y Saneamiento Físico Legal realizará el mantenimiento de la base gráfica correspondiente, registrando en la Reserva o Parque, el área intervenida, autorizada por el Ministerio de Cultura y materia de PMAR.

33.6 Tratándose de áreas que han sido objeto de un PRA, el CIRAS es expedido para las áreas que han sido rescatadas, cuando así lo solicite el administrado y así se indique en el acto administrativo que brinda la conformidad al informe de resultados del PRA.

33.7 Si el proyecto de inversión contiene componentes tanto en área (hectáreas o metros cuadrados) como en longitud (kilómetros o metros), corresponde tramitar el CIRAS de manera individual.

33.8 No procede la expedición del CIRAS en:

a)

Áreas arqueológicas declaradas Patrimonio Cultural de la Nación y con plano de delimitación aprobado.

b)

Áreas arqueológicas que cuentan con plano de delimitación aprobado.

c)

Áreas arqueológicas que cuentan con plano de delimitación registradas en el Ministerio de Cultura, elaborados en el marco de las intervenciones arqueológicas autorizadas por el Ministerio de Cultura y de las actividades funcionales de sus órganos de línea, incorporadas al Sistema de Información Geográfico de Arqueología – SIGDA.

d)

Si el área solicitada tiene antecedentes catastrales arqueológicos registrados en el Ministerio de Cultura, a través del Sistema de Información Geográfico de Arqueología – SIGDA.

e)

En sitios inscritos en la Lista del Patrimonio Mundial de la UNESCO.

f)

Áreas arqueológicas bajo la determinación de la protección provisional.

En los supuestos señalados en los literales a, b, c y e se puede expedir CIRAS cuando se cumpla con lo dispuesto en los numerales 33.4 y 33.6 del presente reglamento.

33.9 El CIRAS no se expide en vía de regularización.

33.10 El CIRAS no está sujeto a plazo de caducidad alguno ni otorga derechos reales sobre el terreno donde se ejecuten las obras civiles y/o proyectos de inversión.

33.11 La expedición del CIRAS no constituye la autorización para la ejecución de obras.

33.12 En el caso de una solicitud de CIRAS en áreas alteradas por factores antrópicos, la procedencia de dicha certificación, está sujeta a las condiciones del terreno y/o las herramientas digitales que permita verificar y/o descartar la presencia de evidencias arqueológicas en superficie.

33.13 Para áreas mayores a 30 ha (300,000 m2) o distancias mayores a 20 km (20,000 m), se debe solicitar la autorización para ejecutar un PEA a fin de expedir el CIRAS.

### CAPÍTULO II

PROCEDIMIENTO

#### Artículo 34. Requisitos

La solicitud de expedición del CIRAS debe presentarse en la plataforma de los servicios en línea del Ministerio de Cultura, o por mesa de partes en versión impresa y digital (CD o DVD), debiendo adjuntar los siguientes requisitos:

1. Solicitud presentada mediante formulario o documento que contenga la misma información, en el que se detalla lo siguiente:

a) Datos generales del solicitante (Nombres y apellidos completos, domicilio y número de Documento Nacional de Identidad o carné de extranjería. En el caso de personas jurídicas, dicha solicitud debe estar suscrita por su representante legal, indicando el número de RUC y el número de la partida registral).

b) Número de partida registral, o número de resolución que otorga la adjudicación o concesión, o código único de inversiones (o código SNIP) que acredite la titularidad de la viabilidad del proyecto de inversión. De no encontrarse registrado el derecho de propiedad ante la SUNARP, se debe acreditar la condición de propietario en forma documental, presentando copia simple de la escritura pública, o minuta, o contrato de compra venta, o se debe acreditar la condición de posesionario a través de una copia simple del respectivo título.

c) Número de constancia y fecha de pago.

2.

Información técnica mediante formulario o documento que contenga:

Memoria descriptiva del terreno (área a certificar), incluyendo nombre del proyecto, antecedentes del terreno, tipo de obra, ubicación política, descripción técnica del proyecto, así como acceso y colindancias, de acuerdo a la guía para la expedición del CIRAS.

3.

Plano perimétrico del área a certificar de acuerdo a la guía para la expedición del CIRAS, presentado en formato .dwg, correctamente georreferenciado en coordenadas UTM, Datum WGS 84, conteniendo la siguiente información: escalas numérica y gráfica, las cuales deben guardar relación con el grillado, membrete, cuadro de datos técnicos, ya sea en área o longitud (con vértice, lado o progresiva, distancia, coordenadas este y norte, área, perímetro, longitud, y servidumbre), suscrito por el profesional competente, en versión impresa y digital.

Los documentos técnicos especificados en el numeral 3) deben expresarse y representarse en unidades de medida de acuerdo a la naturaleza de la obra. Para casos como la implementación de líneas de transmisión, carreteras, tuberías de agua y desagüe, gasoductos, canales, y obras semejantes debe expresarse longitudinalmente en metros

(m) o kilómetros (km), indicando su respectiva servidumbre en metros. Tratándose de predios, áreas de concesión minera, represas, y otros, las áreas se expresan en metros cuadrados (m²) o hectáreas (ha), con su perímetro correspondiente en metros.

#### Artículo 35. De la calificación

35.1 La Dirección de Certificaciones o la Dirección Desconcentrada de Cultura, según el ámbito de sus competencias, tramitan y expiden el CIRAS en un plazo no mayor de veinte días hábiles contados desde el primer día hábil posterior a la presentación de la solicitud, sujetándose a las normas del silencio administrativo positivo.

35.2 Si durante la revisión del expediente se presentan observaciones, éstas son dadas a conocer al administrado, otorgándole un plazo no mayor a diez días hábiles para subsanarlas, periodo durante el cual el procedimiento queda suspendido.

35.3 El plazo para subsanar las observaciones puede ser prorrogado por única vez por el término de diez días hábiles adicionales, siempre y cuando el administrado así lo solicite antes de su vencimiento. Si las observaciones persisten, se mantiene la facultad de la administración de requerir única y exclusivamente, la subsanación de las observaciones, en un plazo adicional de diez días hábiles, bajo apercibimiento de denegar la expedición del CIRAS.

35.4 Luego de verificar que el expediente cumple con los requisitos establecidos, se coordina con el administrado la inspección ocular al área materia de solicitud de certificación.

35.5 Como producto de la inspección ocular y bajo responsabilidad, el inspector elabora un informe en el que indica la duración de la inspección, la accesibilidad y descripción del área, adjuntando fotografías generales. De registrarse evidencias arqueológicas, se acredita su existencia mediante la descripción, localización (coordenadas UTM) y su registro fotográfico, procediendo a desestimar la solicitud.

## TÍTULO III

ANTECEDENTES CATASTRALES ARQUEOLÓGICOS

### CAPÍTULO I

### DISPOSICIONES GENERALES

#### Artículo 36. Definición.

La búsqueda de antecedentes catastrales arqueológicos es un servicio prestado en exclusividad del Ministerio de Cultura mediante el cual, a solicitud del administrado, se emite una constancia que brinda información sobre el catastro de bienes inmuebles prehispánicos actualizado a la fecha de emisión.

La autoridad competente para atender este trámite corresponde a la Dirección de Catastro y Saneamiento Físico Legal, o la que haga sus veces.

#### Artículo 37. Aspectos generales.

37.1 La búsqueda de antecedentes catastrales arqueológicos se realiza sobre un área definida a partir de los datos proporcionados por el administrado en su solicitud.

37.2 La información que se brinda es el resultado de la superposición del área solicitada por el administrado sobre la base gráfica del Ministerio de Cultura, a fin de determinar si, a la fecha de la solicitud, existen bienes inmuebles prehispánicos registrados en dicho ámbito.

37.3 El catastro de bienes inmuebles prehispánicos se encuentra en constante actualización por lo que la constancia que se emite no descarta la presencia y/o registro de evidencias arqueológicas en el área materia de consulta, posterior a la fecha de la emisión de la constancia.

37.4 La constancia de búsqueda de antecedentes catastrales arqueológicos no reemplaza al CIRAS.

### CAPÍTULO II

PROCEDIMIENTO

#### Artículo 38. Requisitos

La solicitud para la búsqueda de antecedentes catastrales arqueológicos debe presentarse en la plataforma de los servicios en línea del Ministerio de Cultura, o por mesa de partes en versión impresa y digital (CD o DVD), debiendo adjuntar los siguientes requisitos:

1. Solicitud presentada mediante formulario o documento que contenga la misma información, en el que se detalla lo siguiente:

a) Datos generales del solicitante (Nombres y apellidos completos, domicilio y número de Documento Nacional de Identidad o carné de extranjería. En el caso de personas jurídicas, dicha solicitud debe estar suscrita por su representante legal, indicando el número de RUC y el número de la partida registral).

b) Número de constancia y fecha de pago.

2.

Memoria descriptiva del área en consulta que incluya cuadro de datos técnicos con referencia a dicha área.

3.

Plano perimétrico del área en consulta, que incluya membrete y con cuadro de datos técnicos. El plano debe estar georreferenciado, con coordenadas UTM, datum WGS 84, indicando la zona geográfica; los datos del cuadro deben reflejar el ámbito en consulta. Se debe presentar en formato impreso y en formato digital (archivos con extensión .dwg o .shp).

38.1 El plazo máximo para atender una solicitud de búsqueda de antecedentes catastrales arqueológicos no debe exceder los treinta días hábiles contados desde el primer día hábil posterior a la presentación de la solicitud.

#### Artículo 39. Trámite

39.1 Si durante la revisión el expediente presenta observaciones, éstas son dadas a conocer al administrado, otorgándole un plazo no mayor a diez días hábiles para subsanarlas.

39.2 El plazo para subsanar las observaciones puede ser prorrogado por única vez por el término de diez días hábiles adicionales, siempre y cuando el administrado así lo solicite antes del vencimiento. Si las observaciones persisten, se mantiene la facultad de la administración de requerir única y exclusivamente, la subsanación de las observaciones, en un plazo adicional de diez días hábiles, bajo apercibimiento de denegar la certificación.

39.3 Luego de culminar la revisión del expediente, la Dirección de Catastro y Saneamiento Físico Legal elabora y emite la constancia de búsqueda de antecedentes catastrales arqueológicos dando por concluido el trámite.

## TÍTULO IV

GESTIÓN DE MATERIALES CULTURALES MUEBLES

### CAPÍTULO I

GENERALIDADES

#### Artículo 40. Objeto

Este título establece las disposiciones para la gestión de los bienes culturales muebles recuperados durante las intervenciones arqueológicas y comprende la conformación de colecciones, su categorización para fines de manejo y estudio, y su custodia.

#### Artículo 41. Colección

41.1 Los bienes culturales muebles constituyen una colección cuando se trata de un conjunto ordenado de objetos, que guardan vinculación entre sí ya sea por pertenecer a un contexto determinado, o por contar con características comunes en razón de su naturaleza, cronología, procedencia, tipología y/o temática.

41.2 La conservación e investigación de los bienes culturales muebles es de primordial importancia, disponiendo el Ministerio de Cultura su exhibición y almacenamiento en museos, depósitos, u otras instituciones con infraestructura adecuada.

#### Artículo 42. Clasificación

Los bienes culturales muebles de una colección como resultado de intervenciones arqueológicas se clasifican en:

42.1 Bienes Culturales Destacados: Son los objetos de primer orden (objetos únicos, hallazgos, contextos cerrados) por su valor informativo y contextual, por sus características plásticas (formales y estéticas), y su grado de integridad (estado de conservación), así como por sus excelentes valores culturales y/o científicos, a fin de ser representativos de su referente contextual de origen y puedan ser museables (exhibidos), preferentemente conservados e investigados y/o custodiados en museos e instituciones de investigación autorizados por el Ministerio de Cultura.

42.2 Bienes Culturales en General: Son los objetos

o restos materiales seleccionados por tener atributos singulares que brindan información significativa de la colección recuperada y por lo tanto son factibles de análisis y estudios complementarios. Estos bienes son conservados y custodiados en museos e instituciones de investigación autorizados por el Ministerio de Cultura, para fines de estudio posterior.

42.3 Bienes Culturales Restringidos: Son los remanentes de las colecciones analizadas, compuestos por fragmentos de material que presentan atributos recurrentes e información limitada. También se consideran en esta categoría a aquellos materiales altamente contaminantes o que han perdido sus condiciones físicas lo que les impide ser analizados. Estos bienes luego de su exhaustiva correspondiente documentación, investigación y análisis; podrán ser reenterrados.

### CAPÍTULO II

REENTIERRO

#### Artículo 43. Generalidades

43.1 Se entiende por reentierro al acto mediante el cual los bienes culturales restringidos, previo inventario y análisis detallados, son reenterrados con el fin de asegurar su resguardo adecuado.

43.2 El reentierro controlado aplica y es posible solo para los bienes culturales restringidos, conforme a lo normado en el presente título, sin que éstos pierdan su condición patrimonial.

43.3 El reentierro para los bienes culturales restringidos, recuperados en el marco de los PRIA y PIA, se realiza en las unidades que se hayan excavado hasta la capa estéril o en otras áreas que el Ministerio de Cultura disponga. Para el caso de los bienes culturales restringidos recuperados en el marco del PEA, PRA, y PMAR, el reentierro se efectúa en el lugar autorizado por el Ministerio de Cultura.

43.4 Excepcionalmente, los restos humanos recuperados en una intervención arqueológica, que sean motivo de una vinculación ancestral y/o familiar por parte de una comunidad originaria y/o campesina, o descendientes directos, pueden ser devueltos y/o reenterrados a solicitud de parte, en consideración a sus tradiciones, costumbres, instituciones y/o identidad cultural.

43.5 En el caso de los restos humanos del periodo colonial y republicano, éstos serán inhumados en cementerios autorizados, mientras que de los restos humanos provenientes de periodos prehispánicos la inhumación será en lugares apropiados para su resguardo, previa evaluación de la entidad.

#### Artículo 44. Requisitos

La solicitud de autorización para un reentierro debe presentarse en la plataforma de los servicios en línea del Ministerio de Cultura, o por mesa de partes en versión impresa y digital (CD o DVD); de acuerdo con los requisitos que se mencionan en los numerales a continuación.

44.1 El reentierro de bienes culturales restringidos:

1. Solicitud presentada mediante formulario o documento que contenga la misma información, en el que se detalla lo siguiente:

a)

Datos generales del solicitante (Nombres y apellidos completos, domicilio y número de Documento Nacional de Identidad o carné de extranjería. En el caso de personas jurídicas, dicha solicitud debe estar suscrita por su representante legal, indicando el número de RUC y el número de la partida registral).

b)

Declaración jurada de compromiso de financiamiento y no afectación al patrimonio cultural.

c)

Nombre del proyecto de procedencia de los bienes.

d)

Número de constancia y fecha de pago.

2. Información técnica mediante formulario o documento que contenga:

a)

Justificación.

b)

Fecha programada para el reentierro.

3. Inventario de los bienes culturales restringidos a ser reenterrados, independiente del inventario general de materiales recuperados como resultado de la intervención arqueológica. Este inventario contiene la siguiente

información: identificación del bien inmueble prehispánico, sector, unidad, y contexto de excavación, tipo de material, cantidad, peso en gramos.

44.2 La autorización para el reentierro de restos humanos recuperados en el marco de intervenciones arqueológicas:

1. Solicitud presentada mediante formulario o documento que contenga la misma información, en el que se detalla lo siguiente:

a)

Datos generales del solicitante (Nombres y apellidos completos, domicilio y número de Documento Nacional de Identidad o carné de extranjería. En el caso de personas jurídicas, dicha solicitud debe estar suscrita por su representante legal, indicando el número de RUC y el número de la partida registral).

b)

Declaración jurada de compromiso de financiamiento y no afectación al patrimonio cultural.

c)

Nombre del proyecto de procedencia de los bienes.

d)

Número de constancia y fecha de pago.

2. Información técnica mediante formulario o documento que contenga:

a) Justificación y sustento de la vinculación ancestral y/o del parentesco.

b) Fecha programada para el reentierro.

3. Copia simple de los resultados de análisis de .liación (ADN), en caso de descendientes directos.

44.3 La solicitud de autorización de reentierro de bienes culturales restringidos y/o restos humanos debe contener en la justificación técnica la ubicación del lugar sugerido, en el cual detalle sus características medioambientales y edafológicas, así como las condiciones de la propiedad, seguridad y cuidado del área propuesta, que permita su adecuado resguardo y protección.

44.4 El plazo máximo para otorgar la autorización del reentierro para bienes culturales restringidos como para restos humanos no debe exceder de los treinta días hábiles contados desde el primer día hábil posterior a la presentación de la solicitud, y se sujeta a las normas del silencio administrativo negativo.

#### Artículo 45. Procedimiento

45.1 La solicitud de reentierro de bienes restringidos y/o restos humanos es presentada ante la Dirección de Calificación de Intervenciones Arqueológicas, para su evaluación correspondiente, una vez finalizado el plazo de ejecución de la intervención arqueológica o en el marco de una autorización de custodia temporal de colecciones.

45.2 Recibida la solicitud de reentierro de bienes restringidos y/o restos humanos se solicita opinión a la Dirección General de Museos, luego de lo cual, el inspector del Ministerio de Cultura coordina con el solicitante la ejecución de la inspección en el lugar del reentierro propuesto, dejando constancia a través de un acta de verificación los materiales y/o restos a reenterrar, y las condiciones técnicas establecidas para el reentierro. La opinión de la Dirección General de Museos, está referida a la categorización, manejo, estudio, depósito y términos de custodia de los bienes solicitados.

45.3 Realizada la evaluación de la solicitud y con la conformidad otorgada por el inspector del Ministerio de Cultura mediante el acta de verificación, la Dirección de Calificación de Intervenciones Arqueológicas emite el oficio otorgando la autorización de reentierro, en la cual se deberá coordinar con el solicitante la fecha de reentierro y las condiciones.

45.4 El inspector del Ministerio de Cultura debe estar presente durante el reentierro, y debe suscribir el acta de conformidad correspondiente con el solicitante, al finalizar el acto.

45.5 El acta de conformidad debe precisar el cumplimiento de las condiciones establecidas en el oficio, constatar los materiales consignados en el inventario del reentierro, e indicar la ubicación en un croquis debidamente georeferenciado, con coordenadas UTM indicando la zona geográfica convencional, Datum WGS84.

45.6 Los gastos que demande el traslado y reentierro son asumidos por el solicitante.

### CAPÍTULO III

VERIFICACIÓN, ENTREGA Y CUSTODIA

#### Artículo 46. Verificación y entrega de las colecciones

46.1 Una vez finalizado el plazo de ejecución de la intervención arqueológica, el Ministerio de Cultura verifica la existencia de las colecciones recuperadas. Esta verificación contrasta el inventario detallado de dichas colecciones.

46.2 El inventario constituye la relación de materiales y contiene la siguiente información:

-Ubicación: Número de caja, Número de bolsa.

-Datos de identificación: Código, Denominación.

-Datos técnicos: Material, cantidad, descripción, dimensiones, peso.

- Datos de origen: Sitio, sector, Área/Unidad/Pozo, Cuadrícula, Capa/UE/Nivel, Contexto, Rasgo/Elemento, Fecha.

46.3 El material debe estar adecuadamente embalado con el fin de garantizar su preservación, de acuerdo a la guía metodológica establecida por la Dirección General de Museos del Ministerio de Cultura.

46.4 Luego de la verificación, se redacta un acta en dos ejemplares suscrita por el inspector del Ministerio de Cultura y el director de la intervención arqueológica; posteriormente se realiza la entrega de las colecciones al Ministerio de Cultura en el lugar indicado por éste, o se solicita su custodia.

#### Artículo 47. Autorización para la custodia de las colecciones obtenidas en el marco de las intervenciones arqueológicas

47.1 La custodia es la entrega temporal de las colecciones recuperadas únicamente con fines de investigación. Finalizada la custodia, el Ministerio de Cultura dispone la ubicación del depósito final de las colecciones.

47.2 A solicitud de parte, el Ministerio de Cultura otorga la autorización temporal para la custodia de las colecciones a favor del director, los investigadores, o las instituciones (incluyendo la persona jurídica como titular y financista de un PEA o PRA) que hayan participado en su recuperación durante el transcurso de la intervención arqueológica.

47.3 La custodia se solicita luego de verificar el inventario de materiales en el lugar donde se realizaron las intervenciones arqueológicas, o en donde se encuentren almacenadas las colecciones.

47.4 Los solicitantes proceden de acuerdo a lo autorizado y asumen la obligación de garantizar el adecuado almacenamiento, conservación, y seguridad de las colecciones bajo su custodia.

47.5 Los solicitantes asumen la obligación de entregar un informe detallando el tipo de análisis e investigación realizado con las colecciones y sus resultados, en el plazo establecido en la resolución de autorización.

#### Artículo 48. Duración de la custodia

La autorización para la custodia de las colecciones obtenidas en el marco de las intervenciones arqueológicas se otorga por el plazo máximo de un año, y puede ser renovada anualmente hasta por un plazo máximo de cinco años consecutivos.

En los casos que la custodia sea autorizada a favor de instituciones, ésta se otorga mediante convenio suscrito con el Ministerio de Cultura, estableciéndose las condiciones y el plazo en el mismo documento. Dichas instituciones deben acreditar haber participado en la recuperación de las colecciones durante el transcurso de la intervención arqueológica.

#### Artículo 49. Requisitos

La solicitud de autorización para la custodia de las colecciones obtenidas en el marco de las intervenciones arqueológicas debe presentarse en la plataforma de los servicios en línea del Ministerio de Cultura, o por mesa de partes en versión impresa y digital (CD o DVD), adjuntando los siguientes requisitos:

1. Solicitud presentada mediante formulario o documento que contenga la misma información, en el que se detalla lo siguiente:

a)

Datos generales del solicitante (Nombres y apellidos completos, domicilio y número de Documento Nacional de Identidad o carné de extranjería. En el caso de personas jurídicas, dicha solicitud debe estar suscrita por su representante legal, indicando el número de RUC y el número de la partida registral).

b)

Declaración jurada de compromiso de financiamiento y no afectación al patrimonio cultural.

c) Número de constancia y fecha de pago.

2. Información técnica mediante formulario o documento que contenga:

a)

Justificación.

b)

Plan de investigación.

c)

Cronograma.

d)

Ubicación y características del depósito temporal.

e)

Metodología y técnicas empleadas durante los trabajos de gabinete y laboratorio, indicando los tipos de muestreo y análisis que se proyecten realizar.

f) Personal del proyecto y responsabilidades.

g)

Descripción de las medidas de conservación y seguridad que se adoptarán.

3. Inventario detallado de los materiales solicitados.

49.1 El plazo máximo para otorgar la autorización de custodia de las colecciones obtenidas en el marco de las intervenciones arqueológicas no debe exceder los treinta días hábiles contados desde el primer día hábil posterior a la presentación de la solicitud, y se sujeta a las normas del silencio administrativo negativo.

#### Artículo 50. Procedimiento

50.1 La solicitud es evaluada por la Dirección de Calificación de Intervenciones Arqueológicas, emitiendo el acto resolutivo que otorga la custodia en donde se establecen las condiciones de la misma.

50.2 El Ministerio de Cultura tiene la facultad para verificar la existencia de los depósitos en donde se almacena la colección durante la custodia. Estos depósitos deben tener las condiciones adecuadas para la conservación y seguridad de los materiales.

50.3 En caso de no cumplir con las condiciones para la conservación y seguridad, el Ministerio de Cultura puede dejar sin efecto la resolución de autorización de custodia de las colecciones obtenidas en el marco de las intervenciones arqueológicas, sin perjuicio de iniciar las acciones legales que correspondan.

50.4 Finalizado el plazo de la custodia, los solicitantes deben entregar los bienes muebles en el lugar dispuesto por el Ministerio de Cultura, y el informe de los resultados en el plazo señalado en la resolución de autorización.

#### Artículo 51. Renovación para la custodia de las colecciones obtenidas en el marco de las intervenciones arqueológicas

La vigencia de la autorización para la custodia de las colecciones obtenidas en el marco de las intervenciones arqueológicas puede ser renovada anualmente hasta por un plazo máximo de cinco años consecutivos.

51.1 Requisitos:

1. Solicitud presentada mediante formulario o documento que contenga la misma información, en el que se detalla lo siguiente:

a)

Datos generales del solicitante (Nombres y apellidos completos, domicilio y número de Documento Nacional de Identidad o carné de extranjería. En el caso de personas jurídicas, dicha solicitud debe estar suscrita por su representante legal, indicando el número de RUC y el número de la partida registral).

b)

Declaración jurada de compromiso de financiamiento y no afectación al patrimonio cultural.

c)

Número de resolución directoral que autorizó la custodia.

d) Número de constancia y fecha de pago.

2. Información técnica mediante formulario o documento que contenga:

a)

Justificación para solicitar la renovación.

b)

Cronograma.

c)

Ubicación y características del depósito temporal.

d) Avance de los análisis de los materiales bajo custodia, de ser el caso.

51.2 La Dirección de Calificación de Intervenciones Arqueológicas o la autoridad delegada para dicho efecto otorga la renovación de la vigencia de una custodia, en el plazo de diez días hábiles contados desde el primer día hábil posterior a la presentación de la solicitud, y se sujeta a las normas del silencio administrativo negativo.

## TÍTULO V

EXPORTACIÓN DE MUESTRAS ARQUEOLÓGICAS CON FINES DE INVESTIGACIÓN CIENTÍFICA

### CAPÍTULO I

GENERALIDADES

#### Artículo 52. Objeto

52.1 El presente título regula las disposiciones para la exportación de muestras arqueológicas recuperadas durante las intervenciones arqueológicas, o aquellas que provienen de colecciones o fondos museográficos, para la realización de análisis científicos en laboratorios del extranjero.

52.2 Cuando se trate de muestras recuperadas en intervenciones arqueológicas que no formen parte de colecciones o fondos museográficos, la solicitud para la exportación de muestras es evaluada por la Dirección de Calificación de Intervenciones Arqueológicas con la opinión técnica de la Dirección General de Museos.

#### Artículo 53. Solicitantes

Pueden solicitar la exportación de muestras arqueológicas con fines científicos los profesionales en arqueología o investigadores de cualquier ámbito científico que acrediten el desarrollo de una investigación de carácter arqueológico en curso; siempre y cuando no adeuden resultados de anteriores análisis científicos.

## TÍTULO VI

AUTORIZACIÓN PARA LA EXPORTACIÓN DE MUESTRAS ARQUEOLÓGICAS CON FINES DE INVESTIGACIÓN CIENTÍFICA

#### Artículo 54. Requisitos

La solicitud de autorización para la exportación de muestras arqueológicas con fines de investigación científica debe presentarse en la plataforma de los servicios en línea del Ministerio de Cultura, o por mesa de partes en versión impresa y digital (CD o DVD).

La solicitud de autorización debe adjuntar los siguientes requisitos:

1. Solicitud presentada mediante formulario o documento que contenga la misma información, en el que se detalla lo siguiente:

a) Datos generales del solicitante (Nombres y apellidos completos, domicilio y número de Documento Nacional de Identidad o carné de extranjería. En el caso de personas jurídicas, dicha solicitud debe estar suscrita por su representante legal, indicando el número de RUC y el número de la partida registral).

b) Número de constancia y fecha de pago.

2. Información técnica mediante formulario o documento que contenga:

a)

Lugar de procedencia de las muestras, indicando el nombre del bien arqueológico prehispánico y el nombre del proyecto, ubicación política y datos del contexto arqueológico.

b) Finalidad de los análisis.

c)

Tipo de análisis (indicar el análisis específico y si éste es destructivo o no destructivo) y nivel de tratamiento de las muestras.

d)

Datos cuantitativos y cualitativos de las muestras (tipo de material, cantidad, peso).

e)

Lugar y nombre del laboratorio o laboratorios en los que se realizará inicialmente el o los análisis.

3. Fotografías individualizadas de las muestras, siempre y cuando el tamaño y tipo de éstas así lo permita.

54.1 El plazo máximo para otorgar una autorización para la exportación de muestras arqueológicas no debe exceder los quince días hábiles contados desde el primer día hábil posterior a la presentación de la solicitud, y se sujeta a las normas del silencio administrativo negativo.

#### Artículo 55. Procedimiento

55.1 De ser necesaria la contrastación de la descripción de los datos cuantitativos y cualitativos con las fotografías individualizadas de las muestras arqueológicas, el solicitante presenta físicamente dichas muestras ante el Ministerio de Cultura, etiquetadas con el número de expediente. Luego de su evaluación, serán devueltas dentro del plazo de calificación de la solicitud.

55.2 De corresponder, se coordina con la Dirección Desconcentrada de Cultura o museo de procedencia a cargo de las muestras arqueológicas a exportar, para su traslado respectivo.

55.3 La autorización es emitida mediante resolución viceministerial. En el caso de análisis destructivos, la resolución de autorización retira la condición de bien integrante del Patrimonio Cultural de la Nación de las muestras.

55.4 La resolución viceministerial debe indicar si el traslado es realizado personalmente, en cuyo caso se debe indicar el nombre de la persona, así como su DNI

o

pasaporte, o de ser el caso, se debe indicar el nombre del servicio de courier internacional. El administrado es responsable de cualquier eventualidad que implique daño

o

pérdida de las muestras.

55.5 En el caso de análisis no destructivos, la salida de las muestras es autorizada por el plazo solicitado por el investigador, siempre y cuando no sea mayor a un año. Este plazo es prorrogable por igual periodo debidamente justificado y por única vez, al término del cual las muestras deben ser devueltas al Ministerio de Cultura.

55.6 Luego de finalizar los análisis, el titular de la autorización presenta los informes científicos y/o la publicación de los resultados en un plazo máximo de un año, contado a partir de la obtención de los mismos, indicando el o los laboratorios involucrados en los análisis.

## TÍTULO VII

SISTEMA DE INFORMACIÓN GEOGRÁFICO DE ARQUEOLOGÍA – SIGDA

#### Artículo 56. Definición

56.1 El Sistema de Información Geográfico de Arqueología – SIGDA es una plataforma tecnológica oficial que contiene un sistema de información que permite buscar, superponer y visualizar la información del catastro de los bienes inmuebles arqueológicos prehispánicos del Perú.

56.2 El Sistema de Información Geográfico de Arqueología - SIGDA está a cargo del Viceministerio de Patrimonio Cultural e industrias Culturales. La operatividad técnico funcional del Sistema de Información Geográfico de Arqueología - SIGDA la asume la Dirección de Catastro y Saneamiento Físico Legal de la Dirección de General de Patrimonio Arqueológico Inmueble. Su accesibilidad y manejo se establece mediante un manual de usuario.

56.3 El Sistema de Información Geográfico de Arqueología -SIGDA se desarrolla mediante la incorporación, el registro y actualización de datos catastrales generados de:

-Las actividades funcionales a cargo de las unidades orgánicas competentes, en materia de identificación registro, delimitación, actualización de información catastral, declaratoria y saneamiento legal de los bienes inmuebles prehispánicos.

-

Los resultados de las intervenciones arqueológicas autorizadas por el Ministerio de Cultura.

-

Los antecedentes catastrales arqueológicos ubicados en los repositorios y archivos del Ministerio de Cultura.

56.4 La información catastral proporcionada en el Sistema de Información Geográfico de Arqueología

– SIGDA no reemplaza a los procedimientos de emisión del Certificado de Inexistencia de Restos Arqueológicos (CIRA), ni de autorización de proyectos de evaluación arqueológica (PEA), ni planes de monitoreo arqueológico (PMA), los cuales se sustentan técnica y metodológicamente con la realización de trabajos de campo, in situ, en las áreas materia de consulta, de acuerdo a los requisitos establecidos en el presente Reglamento para cada caso.

2127933-1

